import { Router, CanActivate, ActivatedRouteSnapshot } from '@angular/router';
import { User } from '../models/user';
import { Injectable } from '@angular/core';

//This service defines the entitlements/access of Users on the app pages based on roles. 
//The app page path parameter is passed from routes configuration
@Injectable()
export class RoleGuardService implements CanActivate {
    constructor(public router: Router) { }

    canActivate(routerSnapshot : ActivatedRouteSnapshot): boolean {
        let user: User = JSON.parse(sessionStorage.getItem('currentUser'));
        let path = routerSnapshot.data.path;
        if (user && user.userName) {
            let userRole = user.role;
            if (user.role === "USER" && path == "ViewUser") {
                this.router.navigate(['/query']);
                return false;
            }
            else if (user.role === "USER" && path == "AddUser") {
                this.router.navigate(['/query']);
                return false;
            }
            else if ((user.role === "USER" ||user.role === "GROUP_ADMIN") && path == "ViewGroups") {
                this.router.navigate(['/query']);
                return false;
            }
            else if ((user.role === "USER" ||user.role === "GROUP_ADMIN") && path == "AddGroups") {
                this.router.navigate(['/query']);
                return false;
            }
            else{
                return true;
            }
        }
        else {
            this.router.navigate(['/login']);
        }
    }
}