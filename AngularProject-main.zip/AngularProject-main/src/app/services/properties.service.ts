import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Properties } from '../models/properties';

@Injectable()
export class PropertiesService {

    static properties: Properties;

    constructor(private http: HttpClient) { }

    initializeProperties() {
       return this.http.get('api/properties').map((properties: Properties) => {
            PropertiesService.properties = properties;
        }).toPromise();
    }
}
