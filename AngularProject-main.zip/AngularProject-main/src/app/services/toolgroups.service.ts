import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ToolGroups } from '../models/ToolGroups';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
};

@Injectable()
export class ToolGroupsService {
    public allToolGroups: ToolGroups[];

    constructor(private http: HttpClient) { }

    public async getAllToolGroups(getDefaultGroups: boolean, reload: boolean): Promise<ToolGroups[]> {
        if (this.allToolGroups && !reload) {
            console.log('Service Call Not required. Data already present.');
            return this.allToolGroups;
        } else {
        console.log('Backend Service Call required.');
        this.allToolGroups= await this.http.get<ToolGroups[]>('getToolGroups?getDefaultGroups=' + getDefaultGroups, httpOptions).toPromise();
        console.log("this.allToolGroups", this.allToolGroups);
        return this.allToolGroups;
        }
    }

    public getToolGroup(): Observable<ToolGroups> {
        return this.http.get<ToolGroups>('getToolGroupById', httpOptions);
    }

    public getToolGroupById(groupId: String): Observable<ToolGroups> {
        return this.http.get<ToolGroups>('getToolGroupById?groupId=' + groupId, httpOptions);
    }

    public createToolGroup(toolGroup: ToolGroups): Observable<ToolGroups> {
        return this.http.post<ToolGroups>('addModifyToolGroup', toolGroup, httpOptions);
    }

    public deleteToolGroup(groupId: string): Observable<ToolGroups> {
        return this.http.get<ToolGroups>('deleteToolGroup?groupId=' + groupId, httpOptions);
    }
}

