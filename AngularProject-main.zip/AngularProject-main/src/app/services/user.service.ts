import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Group } from '../models/Group';
import { User } from '../models/user';
import { QueryService } from './query.service';

@Injectable()
export class UserService {
  private user: User;

  groups: Group;
  factories;
  controlFactories = [] as Group[];
  engageFactories = [] as Group[];
  private loginSubject: Subject<User> = new BehaviorSubject<User>({} as User);

  constructor(private http: HttpClient, private queryService : QueryService) {
    this.user = JSON.parse(sessionStorage.getItem('currentUser'));
    if (this.user) {
      this.loginSubject.next(this.user);
    }
  }

  public getUser() {
    return this.user;
  }
  public onLoginStateChanged() {
    return this.loginSubject;
  }
  public onEngageFactoryChange() {
    return this.engageFactories;
  }
  public onControlFactoryChange() {
    return this.controlFactories;
  }

  public login(username: string, password: string): Observable<User> {
    return this.http.post<User>('api/login', { userName: username, password: password })
      .map(user => {
        this.user = user;
        console.log("Logging Fetched User:", this.user);
        sessionStorage.setItem('currentUser', JSON.stringify(this.user));
        this.loginSubject.next(this.user);
        return user;
      });
  }

  logout() {
    sessionStorage.removeItem('currentUser');
    sessionStorage.removeItem('environment');
    this.queryService.clearData();
    this.loginSubject.next(null);
    window.location.reload();
  }
}
