import { Router, CanActivate } from '@angular/router';
import { User } from '../models/user';
import { Injectable } from '@angular/core';

@Injectable()
export class AuthGuardService implements CanActivate {
    constructor(public router: Router) { }

    canActivate(): boolean {
        let user: User = JSON.parse(sessionStorage.getItem('currentUser'));
        if (user && user.userName) {
           return true;
        }
        else {
            this.router.navigate(['/login']);
        }
    }
}