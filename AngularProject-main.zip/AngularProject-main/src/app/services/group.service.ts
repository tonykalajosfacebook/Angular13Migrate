// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { Observable } from 'rxjs/Observable';
// import { ReplaySubject } from 'rxjs/ReplaySubject';
// import { Group } from '../models/Group';


// @Injectable()
// export class GroupService {
//   private groupSubject = new ReplaySubject<any>(1);
//   private accessSubject = new ReplaySubject<any>(1);

//   constructor(private http: HttpClient) { }

//   getGroups(): Observable<Group[]> {
//     return this.http.get<Group[]>('configs-service/api/groups');
//   }

//   requestGroup(group: Group): Observable<String> {
//     return this.http.post<String>('configs-service/api/groups', group);
//   }

//   public onGroupSet() {
//     return this.groupSubject;
//   }

//   public setGroup(group) {
//     this.groupSubject.next(group);
//   }

//   public returnAccess() {
//     return this.accessSubject;
//   }

//   public getFactoriesPaginated(pageNum: number, size: number): Observable<Group[]> {
//     return this.http.get<Group[]>('configs-service/api/groups/pagination/' + pageNum + '/' + size);
//   }

//   public getFactoriesCount(): Observable<number> {
//     return this.http.get<number>('configs-service/api/groups/count');
//   }

//   public archiveFactory(factoryName: string): Observable<Object> {
//     return this.http.put('configs-service/api/groups/' + factoryName + '/archive/true', {});
//   }

//   public unArchiveFactory(factoryName: string): Observable<Object> {
//     return this.http.put('configs-service/api/groups/' + factoryName + '/archive/false', {});
//   }

//   public updateApprovalStatus(factoryName: string, status: string): Observable<Object> {
//     return this.http.put('configs-service/api/groups/' + factoryName + '/status/' + status, {});
//   }

//   public updateFactoryEmail(factory: Group) {
//     return this.http.patch('configs-service/api/groups/' + factory.name + '/email', factory.factoryOwnerEmail);
//   }
// }
