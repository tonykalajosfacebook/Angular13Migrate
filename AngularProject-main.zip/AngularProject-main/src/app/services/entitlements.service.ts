import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Entitlement } from '../models/Entitlement';

const httpOptions = {
  headers: new HttpHeaders(
    {
      'Content-Type': 'application/json'
    })
};

@Injectable()
export class EntitlementsService {

  constructor(private http: HttpClient) { }

  findAllEntitlementByFactoryName(factoryName: string): Observable<Entitlement[]> {
    return this.http.get<Entitlement[]>('configs-service/api/entitlements?factory=' + factoryName, httpOptions);
  }
  public getEntitlementsPaginated(pageNum: number, size: number): Observable<Entitlement[]> {
    return this.http.get<Entitlement[]>('configs-service/api/entitlements?page=' + pageNum + '&size=' + size);
  }
  public getEntitlementsPaginatedByAdGroup(adGroup: string, pageNum: number, size: number): Observable<Entitlement[]> {
    return this.http.get<Entitlement[]>('configs-service/api/entitlements/paginated?adGroup=' + adGroup + '&pageNum=' + pageNum + '&size=' + size);
  }
  public addEntitlements(entitlement: Entitlement): Observable<Entitlement> {
    return this.http.post<Entitlement>('configs-service/api/entitlements', entitlement);
  }
  public deleteEntitlement(id: String): Observable<String> {
    return this.http.delete<String>('configs-service/api/entitlements/' + id);
  }
  public getEntitlementsCount(): Observable<number> {
    return this.http.get<number>('configs-service/api/entitlements/count');
  }
  public updateEntitlementADGroup(entitlement: Entitlement) {
    return this.http.patch('configs-service/api/entitlements/' + entitlement.id + '/ad-group', entitlement.adGroup);
  }
  public getEntitlementData(adGroup: String): Observable<Entitlement> {
    return this.http.get<Entitlement>('configs-service/api/entitlements/' + adGroup);
  }
}

