import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { PmanUser } from '../models/PmanUser';
import { HttpErrorResponse } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
};

@Injectable()
export class PmanUserService {
  public allPmanUsers: PmanUser[];

  constructor(private http: HttpClient) { }

  public async getAllPmanUsers(racfId: string, reload: boolean): Promise<PmanUser[]> {
    if (this.allPmanUsers && !reload) {
      console.log('Service Call Not required. Data already present.');
      return this.allPmanUsers;
    } else {
      console.log('Backend Service Call required.');
      this.allPmanUsers = await this.http.get<PmanUser[]>('getAllUsers?racfId=' + racfId, httpOptions).toPromise();
      return this.allPmanUsers;
    }
  }

  public getUserGroupsForCreateUser(racfId: string ): Observable<PmanUser> {
    return this.http.get<PmanUser>('getUserGroupsForCreateUser?racfId=' + racfId, httpOptions).catch(this.errorHandler);
  }

  public getUserGroupsforUpdateUser(racfId: string , userId: string): Observable<PmanUser> {
    return this.http.get<PmanUser>('getUserGroupsForUpdateUser?racfIdLoggedInUser=' +
    racfId + '&userId=' + userId, httpOptions).catch(this.errorHandler);
  }

  public createUser(pmanUser: PmanUser ): Observable<PmanUser> {
    return this.http.post<PmanUser>('createUser', pmanUser , httpOptions).catch(this.errorHandler);
  }

  public deleteUser(userName: string, racfIdLoggedInUser: string): Observable<PmanUser> {
    return this.http.get<any>('deleteUser?userName=' + userName + '&racfIdLoggedInUser=' + racfIdLoggedInUser, httpOptions).catch(this.errorHandler);
  }

  public getDBEnvironments(): Observable<string[]> {
    return this.http.get<any>('getDBEnvironments', httpOptions);
  }

  public errorHandler(error: HttpErrorResponse) {
    return Observable.throwError(error.message || 'Server Error');
  }
}

