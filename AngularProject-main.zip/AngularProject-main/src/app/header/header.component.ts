import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Group } from '../models/Group';
import { User } from '../models/user';
// import { GroupService } from '../services/group.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit {
@Output() public sidenavToggle = new EventEmitter();
  isNavbarCollapsed = true;
  isLoginPage;
  user: User;
  factories = [] as Group[];
  groups = [] as Group[];
  entitlement: any;
  currentFactory = {} as Group;
  selectedFactory= {} as Group;
  environments: string[] = ['DEVINT', 'DEVINT2'];
  version: string = 'DEVINT';

  constructor(
    private router: Router,
    private userService: UserService,
    // private groupService: GroupService, 
    private activeRoute : ActivatedRoute
  ) {
  }
  get headerImage() {
    return '../../assets/images/RoboticsLogo.png';
  }

  onVersionChanged(version: string) {
    this.version=version;
    console.log('selected environment', version);
    sessionStorage.setItem('environment',  version);
    this.router.navigate(['/query']);
    this.router.navigateByUrl('/pman-user', { skipLocationChange: true }).then(() => {
      this.router.navigate(['/query']);
    });
  }

  loadFactories() {
    sessionStorage.setItem('currentFactory', "Support Tool");
  }

  ngOnInit() {
    this.version = sessionStorage.getItem('environment');
    
    this.userService.onLoginStateChanged().subscribe((user: User) => {
      this.user = user;
      if (user) {
        const controlFactories = this.userService.onControlFactoryChange();
        // this.groupService.getGroups().subscribe(res  => {
        //     this.groups = res;
        //     this.loadFactories();
        // });
      }
    });
  }
  
public onToggleSidenav = () => {
  this.sidenavToggle.emit();
}

getroute() {
  return this.activeRoute.firstChild.routeConfig.path;
}

getRouteForProfile() {
  return this.activeRoute;
}
  setFactory(factory: Group) {
    this.currentFactory = factory;
    // this.groupService.onGroupSet().next(this.currentFactory);
    // this.groupService.returnAccess().next(true);
    sessionStorage.setItem('currentFactory',  "Support Tool");
  }

  logout() {
    sessionStorage.removeItem('currentFactory');
    sessionStorage.removeItem('environment');
    this.router.navigate(['/login']);
    this.userService.logout();
  }
}
