import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ToolGroupsAddModifyComponent } from './tool-groups-add-modify.component';

describe('ToolGroupsAddModifyComponent', () => {
  let component: ToolGroupsAddModifyComponent;
  let fixture: ComponentFixture<ToolGroupsAddModifyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ToolGroupsAddModifyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ToolGroupsAddModifyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
