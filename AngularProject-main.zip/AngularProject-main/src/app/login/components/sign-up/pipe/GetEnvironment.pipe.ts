import { Pipe, PipeTransform } from '@angular/core';
import { Entitlement } from '../../../../models/Entitlement';

@Pipe({ name: 'getEnvironment' })
export class GetEnvironment implements PipeTransform {
  transform(entitlement: Entitlement): string {
    let environment = '';
    if (entitlement.adGroup.startsWith('AP_T')) { environment = 'Dev/Test'; }
    if (entitlement.adGroup.startsWith('AP_P')) { environment = 'Production'; }

    return environment;
  }
}
