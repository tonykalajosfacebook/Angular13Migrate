import { Pipe, PipeTransform } from '@angular/core';

import { Entitlement } from '../../../../models/Entitlement';

@Pipe({ name: 'getPermission' })
export class GetPermissionPipe implements PipeTransform {
  transform(entitlement: Entitlement): string {
    let permission = '';
    if (entitlement.control) {
      permission = 'Control';
    } else {
      permission = 'Engage';
    }
    if (entitlement.writeAccess) {
      permission += ' Read Write';
    } else {
      permission += ' Read Only';
    }
    return permission;
  }
}
