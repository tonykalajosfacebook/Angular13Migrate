import { Component, OnInit } from '@angular/core';
// import { GroupService } from '../../../services/group.service';
import { EntitlementsService } from '../../../services/entitlements.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SelectItem } from 'primeng/api';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  selectedFactory;
  groups: {};
  factories: SelectItem[] = [];
  entitlements: {};
  permission = '';
  environment = 'Dev/Test';
  isloaded = false;
  constructor(public activeModal: NgbActiveModal, private entitlementService: EntitlementsService) { }

  ngOnInit() {
    // this.groupService.getGroups().subscribe((groups) => {
    //   this.groups = groups;

    //   // tslint:disable-next-line:forin
    //   for (const i in this.groups) {
    //     if (this.groups[i].status === 'Approved' ) {
    //     this.factories.push({ label: this.groups[i].name, value: this.groups[i].name });
    //   }
    // }
    // });
  }

  loadFactories(value) {
    this.isloaded = true;

    this.entitlementService.findAllEntitlementByFactoryName(value)
      .subscribe(ent => {
        this.entitlements = ent;
      });
  }
}
