// import { Component, OnInit, Inject } from '@angular/core';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
// import { MessageService } from 'primeng/api';
// import { GroupService } from '../../../services/group.service';
// import { PropertiesService } from '../../../services/properties.service';

// @Component({
//   selector: 'app-factory-sign-up',
//   templateUrl: './factory-sign-up.component.html',
//   styleUrls: ['./factory-sign-up.component.css']
// })
// export class FactorySignUpComponent implements OnInit {

//   loading = false;
//   message = '';
//   isRegistered = false;

//   groups: {};
//   factoryErrorMessage = '';
//   valid: boolean;
//   env = 'Dev 2';
//   public submitted = false;
//   public factorySignUpForm: FormGroup;
//   constructor(private formBuilder: FormBuilder,
//     public activeModal: NgbActiveModal, private groupService: GroupService, private messageService: MessageService, private propertiesService: PropertiesService) {
//    // this.env = propertiesService.initializeProperties;
//   }

//   ngOnInit() {
//     this.factorySignUpForm = this.formBuilder.group({
//       factoryName: ['', Validators.required],
//       factoryEmail: ['', [Validators.required,

//       // tslint:disable-next-line:max-line-length
//       Validators.pattern(/^(([^<>()\[\]\\.,;:\s@']+(\.[^<>()\[\]\\.,;:\s@']+)*)|('.+'))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]]
//     });
//     this.groupService.getGroups()
//       .subscribe(groups => {
//         this.groups = groups;
//       });
//   }

//   get f() { return this.factorySignUpForm.controls; }

//   factoryRegister(group) {
//     this.submitted = true;

//     if (this.factorySignUpForm.invalid) {
//       return;
//     }
//     if (this.isRequestGroupExists(group.factoryName)) {
//       this.groupService.requestGroup({ name: group.factoryName, factoryOwnerEmail: group.factoryEmail, status: 'Unapproved' })
//         .subscribe(groups => {
//           this.isRegistered = true;
//           this.message = 'Thank you for your submission. Please send the email which was just generated. We will review your' +
//             ' registration details and get back to you if we have any questions.';
//           window.open('mailto:' + 'test@test.com'
//             // tslint:disable-next-line:max-line-length
//                     , '_self');
//         },
//           err => {
//             this.factoryErrorMessage = 'Something went wrong, Please try after sometime.';
//             this.submitted = false;
//             this.loading = false;
//           }
//         );
//     }
//   }
//   onReset() {
//     this.factorySignUpForm.reset();
//   }

//   mail() {
//     window.open('mailto:' + 'soumitra.chatterjee@tiaa.org'  , '_self');

//   }
//   isRequestGroupExists(groupName) {
//     for (const i in this.groups) {
//       if (this.groups[i].name === groupName) {
//         this.factoryErrorMessage = 'Factory already exists, please provide a unique factory name';
//         return false;
//       }
//     }
//     return true;
//   }
// }
