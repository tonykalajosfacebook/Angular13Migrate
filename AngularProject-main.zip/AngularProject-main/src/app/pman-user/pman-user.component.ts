import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { PmanUserService } from '../services/pmanuser.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { ConfirmationDialogService } from '../common-components/confirmation-dialog/confirmation-dialog.service';
import { PmanUserAddModifyComponent } from '../pman-user-add-modify/pman-user-add-modify.component';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';

@Component({
  selector: 'app-pman-user',
  templateUrl: './pman-user.component.html'
})
export class PmanUserComponent implements OnInit {
  public dataSource;
  public isLoading = true;
  public displayedColumns: string[] = ['userId', 'racfId', 'groupsAssignedTo', 'adminGroupsAssignedTo', 'Modify'];
  public searchString: string;
  private modalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
  };

  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  deleteUserAllowed: boolean;
  updateUserAllowed: boolean;

  constructor(
    private pmanUserService: PmanUserService,
    private confirmationDialogService: ConfirmationDialogService,
    private snackBar: MatSnackBar,
    private modalService: NgbModal,
    private changeDetectorRefs: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.refresh();
    this.initializeDataTable(true);
  }

  initializeDataTable(reload: boolean) {
    const user = JSON.parse(sessionStorage.getItem('currentUser'));

    this.deleteUserAllowed = user.deleteUserAllowed;
    this.updateUserAllowed = user.updateUserAllowed;

    this.pmanUserService.getAllPmanUsers(user.userName, reload).then(response => {
      this.dataSource = new MatTableDataSource(response);
      console.log('Pman Users Response/DS -->>>>' + response + ' / ' + this.dataSource );
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      this.isLoading = false;
    });
  }

  deleteUser(userName: string) {
    const user = JSON.parse(sessionStorage.getItem('currentUser'));
    const config = new MatSnackBarConfig();
    config.duration = 4000;
    config.panelClass = ['orange-snackbar'];
    config.horizontalPosition = 'end';
    config.verticalPosition = 'top';

    this.confirmationDialogService.confirm('Delete User', 'Do you really want to delete this User?').then((confirmed) => {
      if (confirmed) {
        this.snackBar.open('Working On it' , '', config);
        this.pmanUserService.deleteUser(userName, user.userName).subscribe(response => {
          console.log(response);
          this.snackBar.dismiss();
          config.panelClass = ['green-snackbar'];
          this.snackBar.open('User ' + userName + ' Deleted Successfully', 'Success', config);

          this.refresh();
          this.initializeDataTable(true);
          this.snackBar.dismiss();
        },
        error => {
          this.snackBar.dismiss();
          config.panelClass = ['red-snackbar'];
          this.snackBar.open('Error:' + error , '', config);
        });
      } else {
        this.snackBar.dismiss();
        this.snackBar.open('deleting has been canceled', 'Success', config);
      }
    });
  }

  applyFilter() {
    const filterValue = this.searchString;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  removeFilter() {
    this.searchString = '';
    const filterValue = this.searchString;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  addModifyUsers(userID?: string) {
    if (userID === undefined || userID === null) { userID = 'NewRecordRequest'; }
    window.sessionStorage.setItem('user-userID', userID);

    const dialogRef = this.modalService.open(PmanUserAddModifyComponent, this.modalOptions);

    dialogRef.result.then((result) => {
      if ( result === 'success' ) { this.initializeDataTable(true); }
    }, (exit) => {});
  }

  refresh() {
    this.changeDetectorRefs.detectChanges();
  }
}