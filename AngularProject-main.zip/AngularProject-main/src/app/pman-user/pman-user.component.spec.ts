import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PmanUserComponent } from './pman-user.component';

describe('PmanUserComponent', () => {
  let component: PmanUserComponent;
  let fixture: ComponentFixture<PmanUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PmanUserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PmanUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
