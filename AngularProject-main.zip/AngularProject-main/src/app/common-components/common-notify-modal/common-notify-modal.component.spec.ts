import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonNotifyModal } from './common-notify-modal.component';

describe('CommonAlertsComponent', () => {
  let component: CommonNotifyModal;
  let fixture: ComponentFixture<CommonNotifyModal>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CommonNotifyModal]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonNotifyModal);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
