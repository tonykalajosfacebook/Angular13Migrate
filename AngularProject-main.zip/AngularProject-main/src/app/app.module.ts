// MODULES
import { DatePipe } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { NgxLoadingModule } from 'ngx-loading';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AccordionModule } from 'primeng/accordion';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { CalendarModule } from 'primeng/calendar';
import { CheckboxModule } from 'primeng/checkbox';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { InputSwitchModule } from 'primeng/inputswitch';
import { InputTextModule } from 'primeng/inputtext';
import { KeyFilterModule } from 'primeng/keyfilter';
import { MessagesModule } from 'primeng/messages';
import { MultiSelectModule } from 'primeng/multiselect';
import { PaginatorModule } from 'primeng/paginator';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { RadioButtonModule } from 'primeng/radiobutton';
import { TableModule } from 'primeng/table';
import { TabViewModule } from 'primeng/tabview';
import { ToastModule } from 'primeng/toast';
import { TreeTableModule } from 'primeng/treetable';
import { TooltipModule } from 'primeng/tooltip';
import { AppRoutingModule } from './app-routing.module';
import { FileUploadModule } from 'primeng/fileupload';
import {ChipsModule} from 'primeng/chips';

//Angular Material Module
import { MatListModule } from '@angular/material/list';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTableModule } from '@angular/material/table';
import { MatMenuModule } from '@angular/material/menu';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { MatProgressBarModule} from '@angular/material/progress-bar';
import {MatDialogModule} from '@angular/material/dialog';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatRadioModule} from '@angular/material/radio';
import {MatChipsModule} from '@angular/material/chips';
import {MatStepperModule} from '@angular/material/stepper';

// COMPONENTS
import { AppComponent } from './app.component';

// import { FactorySignUpComponent } from './login/components/factory-sign-up/factory-sign-up.component';
import { GetEnvironment } from './login/components/sign-up/pipe/GetEnvironment.pipe';
import { GetPermissionPipe } from './login/components/sign-up/pipe/GetPermission.pipe';
import { SignUpComponent } from './login/components/sign-up/sign-up.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './common-components/footer/footer.component';
import { QueryParamInputComponent } from './query-param-input/query-param-input.component';
import { CommonNotifyModalComponent } from './common-components/common-notify-modal/common-notify-modal.component';

// SERVICES
// import { GroupService } from './services/group.service';
import { UserService } from './services/user.service';
import { EntitlementsService } from './services/entitlements.service';
import { PropertiesService } from './services/properties.service';
import { QueryService} from './services/query.service';
import { PmanUserService} from './services/pmanuser.service';
import { ToolGroupsService } from './services/toolgroups.service';
import { RoleGuardService } from './services/roleguard.service'
import { AuthGuardService } from './services/authguard.service';
import { CommonNotifyModalService } from './common-components/common-notify-modal/common-notify-modal.service';


import { FlexLayoutModule } from '@angular/flex-layout';
import { QueryComponent } from './query/query.component';
import { AddQueryComponent } from './add-query/add-query.component';
import { QueryResultComponent } from './query-result/query-result.component';
import { PmanUserComponent } from './pman-user/pman-user.component'
import { PmanUserAddModifyComponent } from './pman-user-add-modify/pman-user-add-modify.component';
import { ToolGroupsComponent } from './tool-groups/tool-groups.component';
import { ToolGroupsAddModifyComponent } from './tool-groups-add-modify/tool-groups-add-modify.component';
import { BaseUrlInterceptor } from './services/http.interceptor';
import { ConfirmationDialogComponent } from './common-components/confirmation-dialog/confirmation-dialog.component';
import { ConfirmationDialogService } from './common-components/confirmation-dialog/confirmation-dialog.service';

import { MatTooltipModule } from '@angular/material/tooltip';
import { DragDropModule } from '@angular/cdk/drag-drop';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignUpComponent,
    // FactorySignUpComponent,
    HeaderComponent,
    FooterComponent,
    GetPermissionPipe,
    GetEnvironment,
    QueryParamInputComponent,
    PmanUserComponent,
    QueryComponent,
    AddQueryComponent,
    QueryResultComponent,
    PmanUserAddModifyComponent,
    ToolGroupsComponent,
    ToolGroupsAddModifyComponent,
    ConfirmationDialogComponent,
    CommonNotifyModalComponent

  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    AccordionModule,
    ProgressSpinnerModule,
    TabViewModule,
    InputSwitchModule,
    KeyFilterModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    TableModule,
    RadioButtonModule,
    DialogModule,
    TreeTableModule,
    PaginatorModule,
    CheckboxModule,
    ToastModule,
    TooltipModule,
    CalendarModule,
    ConfirmDialogModule,
    MessagesModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    MultiSelectModule,
    DropdownModule,
    ToastModule,
    NgbModule,
    NgxLoadingModule,
    NgxSpinnerModule,
    InputTextModule,
    PdfViewerModule,
    FileUploadModule,
    ChipsModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatSelectModule,
    MatInputModule,
    MatCardModule,
    MatFormFieldModule,
    MatCheckboxModule,
    MatTableModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    FlexLayoutModule,
    MatSortModule,
    MatPaginatorModule,
    MatDialogModule,
    MatSnackBarModule,
    MatExpansionModule,
    MatRadioModule,
    MatChipsModule,
    MatStepperModule,
    MatTooltipModule,
    DragDropModule

  ],
  entryComponents: [
    SignUpComponent,
    // FactorySignUpComponent,
    ConfirmationDialogComponent
  ],
  providers: [
    MessageService,
    ConfirmationService,
    // GroupService,
    EntitlementsService,
    UserService,
    PmanUserService,
    ToolGroupsService,
    RoleGuardService,
    AuthGuardService,
    PropertiesService,
    QueryService,
    ConfirmationDialogService,
    CommonNotifyModalService,
    DialogModule,
    ButtonModule,
    NgbActiveModal,
    DatePipe,
    BrowserAnimationsModule,
    { provide: HTTP_INTERCEPTORS, useClass: BaseUrlInterceptor, multi: true }

  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
