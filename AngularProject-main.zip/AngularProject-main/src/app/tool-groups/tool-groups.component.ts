import { Component, OnInit, ViewChild , ViewEncapsulation } from '@angular/core';
import { ToolGroupsService } from '../services/toolgroups.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { User } from '../models/user';
import { ConfirmationDialogService } from '../common-components/confirmation-dialog/confirmation-dialog.service';
import { MatDialogConfig, MatDialogRef } from '@angular/material/dialog';
import { ToolGroups } from '../models/ToolGroups';
import { ToolGroupsAddModifyComponent } from '../tool-groups-add-modify/tool-groups-add-modify.component';
import { Injectable } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';



import {
  MatSnackBar,
  MatSnackBarConfig
} from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root'
})

@Component({
  selector: 'app-tool-groups',
  templateUrl: './tool-groups.component.html',
  styleUrls: ['./tool-groups.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class ToolGroupsComponent implements OnInit {

  dataSource;
  public isLoading = true;
  displayedColumns: string[] = ['id', 'name', 'description', 'Modify'];
  user: User;
  searchString: string;
  isUpdateGroupAllowed: boolean;
  isDeleteGroupAllowed: boolean;
  toolGroups: ToolGroups = { id: null, name: '', description: ''};
  allToolGroups: ToolGroups[];
  existingToolGroups: string[];
  flowTypeCreate: boolean;
  formErr: boolean;
  private dialogConfig = new MatDialogConfig();

  public toolGroupsAddModifyDialogRef: MatDialogRef<ToolGroupsAddModifyComponent>;

  @ViewChild('toolGroupForm') toolGroupForm: NgForm;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  constructor(
    private toolGroupsService: ToolGroupsService,
    private confirmationDialogService: ConfirmationDialogService,
    private snackBar: MatSnackBar,
    private modalService: NgbModal,
  ) { }

  ngOnInit(): void {
    this.initializeDataTable();
  }
  // ngAfterViewInit() {
  //   this.toolGroupForm.form.valueChanges.subscribe(x => {
  //     this.formErr = false; //hide error message when user starts proving inputs in form
  //   })
  // }

  initializeDataTable() {
    this.user = JSON.parse(sessionStorage.getItem('currentUser'));

    this.isUpdateGroupAllowed = this.user.updateGroupAllowed;
    this.isDeleteGroupAllowed = this.user.deleteGroup;

    console.log(this.user)
    this.toolGroupsService.getAllToolGroups(true, true).then(response => {
      console.log(response);
      this.dataSource = new MatTableDataSource(response);
      console.log(this.dataSource);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      this.isLoading = false;
    });
  }

  /*applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }*/

  applyFilter() {
    const filterValue = this.searchString;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  removeFilter() {
    this.searchString = '';
    const filterValue = this.searchString;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


  deleteToolGroup(groupId: string) {
    const config = new MatSnackBarConfig();
    config.duration = 4000;
    config.panelClass = ['red-snackbar']
    config.horizontalPosition = 'end',
    config.verticalPosition = 'top'

    this.confirmationDialogService.confirm('Delete Group', 'Do you really want to delete this Group?')
      .then((confirmed) => {
        console.log('User confirmed:', confirmed)
        if (confirmed) {
          this.toolGroupsService.deleteToolGroup(groupId).subscribe(response => {
            config.panelClass = ['green-snackbar']
            this.snackBar.open('ToolGroup Deleted Successfully' + groupId, 'Success' , config);
            this.dataSource.data.splice(this.dataSource.data.indexOf(groupId), 1);
            this.initializeDataTable();
          });
        } else {
          console.log('User cancelled the operation');
        }
      })
      .catch(() => console.log('User dismissed the dialog (e.g., by using ESC, clicking the cross icon, or clicking outside the dialog)'));
  }

  initializeToolGroupById(id: string) {
    this.toolGroupsService.getToolGroupById(id).subscribe(response => {
      console.log(response);
      this.toolGroups = response;
      this.toolGroups.description = 'xxxxx';
    });
  }

  fetchAllToolGroups() {
    this.toolGroupsService.getAllToolGroups(true, true).then(response => {
      this.allToolGroups = response;
      this.existingToolGroups = response.map(a => a.name);
      console.log('existing toolGroups: ', this.existingToolGroups);
    });
  }

  addModifyToolGroupModel(groupId?: string) {
    if (groupId === undefined || groupId === null) {  groupId = 'NewRecordRequest';  }
    console.log('tool-groups-GroupID FINAL value' + groupId);
    window.sessionStorage.setItem('tool-groups-GroupID', groupId);

    this.dialogConfig.autoFocus = true;
    this.dialogConfig.maxWidth = '1400vw';
    this.dialogConfig.width = '1111px';
    this.dialogConfig.height = '660px';
    this.dialogConfig.hasBackdrop = false;

    const modalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false,
    };

    this.flowTypeCreate = true;
    const dialogRef = this.modalService.open(ToolGroupsAddModifyComponent, this.dialogConfig);

    // Refresh Data in table grid
    dialogRef.result.then((result) => {
      if ( result === 'success' ) {  this.initializeDataTable(); }
    } , (reason) => { });
  }
}