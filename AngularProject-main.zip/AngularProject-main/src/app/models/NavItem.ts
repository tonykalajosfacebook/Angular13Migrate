export interface NavItem {
    displayName: string;
    disabled?: boolean;
    iconName?: string;
    iconColor?: string;
    route?: string;
    children?: NavItem[];
  }