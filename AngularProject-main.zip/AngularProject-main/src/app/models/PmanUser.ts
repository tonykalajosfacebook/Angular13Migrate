import { ToolGroups } from '../models/ToolGroups';
export interface PmanUser {
	id: string;
	userId: string;
	racfId: string;
	groupsAssignedTo: string;
	groupId?: string;
	selectedRole?: string;
	selectedGroups?:string;
	selectedAdminGroups?:string;
	selectedActions?: string;
	isGroupAdmin?: string;
	availableRoles?: Role[];
	availableActions?: Action[];
	availableGroups?: ToolGroups[];
	availableAdminGroups?: ToolGroups[];
	error?: boolean;
	errorMessage?: string;
}

export interface Role {
	id: string;
	name: string;
	description: string;
	checked? : boolean;
}

export interface Action {
	id: string;
	name: string;
	desc: string;
	url: string;
	isDefault: string
	checked? : boolean;
}