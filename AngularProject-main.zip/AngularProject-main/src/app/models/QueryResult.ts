export interface QueryResult {
    headers: string[];
    columnClass: string[];
    data: ResultDataRow[];
    queryName: string;
    queryId;
    isSelect: string;
    rowsAffected: string;
    isError:string;
    errorMessage:string;
}

export interface Action {
    Id: string;
    name: string;
    desc: string;
    url: string;
    isDefault: string;
}
export interface ResultDataRow {
    element: string[];
}