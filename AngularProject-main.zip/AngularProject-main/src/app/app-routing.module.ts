import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import {PmanUserComponent} from './pman-user/pman-user.component';
import {QueryComponent} from './query/query.component';
import {ToolGroupsComponent} from './tool-groups/tool-groups.component'
import {RoleGuardService as RoleGuard} from './services/roleguard.service';
import { AuthGuardService as AuthGuard } from './services/authguard.service';

const routes: Routes = [
  { path: '*', redirectTo: 'login' , pathMatch: 'full'},
  { path: 'login', component: LoginComponent },
  { path: 'pman-user', component: PmanUserComponent,  canActivate: [RoleGuard] , data: { path : 'ViewUser'} },
  { path: 'tool-groups', component: ToolGroupsComponent, canActivate: [RoleGuard] , data: { path : 'ViewGroups'}},
  { path: 'query', component: QueryComponent, canActivate: [AuthGuard] },

  { path: '', redirectTo: 'query' , pathMatch: 'full', canActivate: [AuthGuard] },
  { path: '**', redirectTo: 'login' , pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: false })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
