import { Component, OnInit, ViewChild } from '@angular/core';
import { Query } from '../models/Query';
import { ToolGroups } from '../models/ToolGroups';
import { FormControl, FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { QueryService } from '../services/query.service';
import { ToolGroupsService } from '../services/toolgroups.service';
import { QueryList, QueryParameters } from '../models/QueryList';
import { MatStepper } from '@angular/material/stepper';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
import { MatDialogRef } from '@angular/material/dialog';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { PmanUser } from '../models/PmanUser';
import { trigger, transition, animate, style } from '@angular/animations';

@Component({
  selector: 'app-add-query',
  templateUrl: './add-query.component.html',
  styleUrls: ['./add-query.component.css'],

  animations: [
    trigger('slideInOut', [
      transition(':enter', [
        style({transform: 'translateY(-100%)'}),
        animate(500, style({ height: 0 }))
      ]),
      transition(':leave', [
        animate(500, style({ height: 100 }))
      ])
    ])
  ]
})

export class AddQueryComponent implements OnInit {

  constructor(
    private queryService: QueryService,
    private toolGroupService: ToolGroupsService,
    private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
    public activeModal: NgbActiveModal,
  ) { }

  @ViewChild('stepper') stepper: MatStepper;

  input: string;
  questionText: string;
  uniqueId: string;
  queryList: QueryList;
  toolgroups: ToolGroups[];
  queryFromList: QueryList;
  query: Query = {id: '', name: '', description: '', queryHelpLink: '' , sql: '', selectedGroups: [], parameters: []};
  finalQueryVar: Query = {id: '', name: '', description: '', queryHelpLink: '' , sql: '', selectedGroups: [], parameters: []};
  isParameterized = ['Y','N'];
  dataTypes = ['String','Number','Date'];
  id;
  queryId: string = null;
  public loading = false;
  formErr: boolean;
  queryNames: string[];
  flowTypeCreate: boolean = true;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  pmanuser: PmanUser;
  public addQueryDialogRef: MatDialogRef<AddQueryComponent>;


  ngOnInit(): void {
    this.initializeQueryGroups();
    this.getAllQueryNames();

    this.id = sessionStorage.getItem('query-queryID');
    console.log('query-queryID passed to modal' + sessionStorage.getItem('query-queryID'));
    if (this.id != null && this.id !== 'NewRecordRequest') {
      this.queryId = this.id;
      this.getQueryById(this.id);
      this.flowTypeCreate = false;
    }

    this.firstFormGroup = this.formBuilder.group({
      queryname: new FormControl('', [Validators.required, Validators.minLength(8)]),
      description: new FormControl('', [Validators.required, Validators.minLength(8)]),
      queryHelpLink: new FormControl(''),
      queryGroup: new FormControl('', [Validators.required]),
      firstSelectedGroupsFormControl: new FormControl(['']),
    });

    this.secondFormGroup = this.formBuilder.group({
      sqlText: new FormControl(null, [Validators.required, Validators.minLength(8)]),
      secondSelectedGroupsFormControl: new FormControl(['']),
      sqlparameters: this.formBuilder.array([])
    });
  }

  // Intializate ToolGroups dropdown
  initializeQueryGroups() {    
    this.toolGroupService.getAllToolGroups(false, true).then(data => {
      this.toolgroups = data;
      for (const group of this.toolgroups) {
        this.query.selectedGroups.push(group.name);
      }
    });
  }

  getAllQueryNames() {
    const user = JSON.parse(sessionStorage.getItem('currentUser'));
    const pmanuser = { id: null, userId: user.userName, racfId: user.userName, groupsAssignedTo: null, adminGroupsAssignedTo: null };

    this.queryService.getAllQueries(pmanuser, false).then(response => {
      console.log(response);
      this.queryNames = response.map(data => data.name);
      window.sessionStorage.setItem('query-queryID', null);
    });
  }

  async saveData() {
    const config = new MatSnackBarConfig();
    config.duration = 4000;
    config.panelClass = ['green-snackbar']
    config.horizontalPosition = 'end',
    config.verticalPosition = 'top'

    // Validation on Query Name should be done in Create Query flow i,e flowTypeCreate = true;
    if (this.flowTypeCreate && this.queryNames.includes(this.firstFormGroup.value.queryname)) {
      this.formErr = true;
      config.panelClass = ['red-snackbar']
      this.snackBar.open('Query: ' + this.firstFormGroup.value.queryname + ' exist. Please create Query with a different Name ', 'failure', config);
      this.stepper.selectedIndex = 0 ;

    } else {
      this.loading = true;
      console.log('Saving Form Data to DB');
      console.log(this.secondFormGroup.value.sqlparameters);
      this.finalQueryVar.id = this.queryId; //  This will be set to null if its a new Query
      this.finalQueryVar.name = this.firstFormGroup.value.queryname;
      this.finalQueryVar.description = this.firstFormGroup.value.description;
      this.finalQueryVar.queryHelpLink = this.firstFormGroup.value.queryHelpLink;
      this.finalQueryVar.sql = this.secondFormGroup.value.sqlText;
      this.finalQueryVar.parameters = this.secondFormGroup.value.sqlparameters;
      this.finalQueryVar.selectedGroups = this.firstFormGroup.value.firstSelectedGroupsFormControl;
      console.log(this.finalQueryVar.selectedGroups);
      console.log(JSON.stringify(this.finalQueryVar));
      const user = JSON.parse(sessionStorage.getItem('currentUser'));
      this.queryService.addQuery(this.finalQueryVar).subscribe(data => {
        console.log(data);
        if (data.isError) {
          this.snackBar.dismiss();
          config.panelClass = ['red-snackbar'];
          this.snackBar.open(data.errorMessage, '', config);
        } else {
          if (this.finalQueryVar.id != null) {
            this.snackBar.open('Query: ' + this.query.name + '  Successfully Updated ', 'Success', config);
          } else {
            this.snackBar.open('Query: ' + this.finalQueryVar.name + '  Successfully Added ', 'Success', config);
          }
          window.sessionStorage.setItem('query-queryID', null);
          this.loading = false;
          this.activeModal.close('success');
        }
      });
    }
  }

  getQueryById(id) {
    this.queryService.getQueryById(id).subscribe(data => {
      this.queryFromList = data;
      this.query.id = this.queryFromList[0].id;
      this.query.name = this.queryFromList[0].name;
      this.query.description = this.queryFromList[0].description;
      this.query.sql = this.queryFromList[0].sql;
      this.firstFormGroup.get('firstSelectedGroupsFormControl').setValue(this.queryFromList[0].associatedGroup.split(','));
      this.firstFormGroup.get('queryname').setValue(this.query.name);
      this.firstFormGroup.controls['queryname'].disable();
      this.firstFormGroup.get('description').setValue(this.query.description);
      this.firstFormGroup.get('queryHelpLink').setValue(this.queryFromList[0].queryHelpLink);
      this.secondFormGroup.get('sqlText').setValue(this.query.sql);
      const queryParams: QueryParameters[] = this.queryFromList[0].parameters;
      this.loadQueryParamsFormArray(queryParams);
      console.log('getQueryById' + this.query);
    });
  }

  loadQueryParamsFormArray(queryParams: QueryParameters[]) {
    queryParams.forEach(params => {
      const formGroup = this.createFilterGroup();

      formGroup.patchValue({
        'name': params.name,
        'dataType': params.dataType,
        'value': params.value,
      });
      this.sqlParamatersFormArray.push(formGroup);
    });
  }

  closeModal() {
    this.activeModal.dismiss();
  }

  createFilterGroup() {
    return this.formBuilder.group({
      name: [],
      dataType: [],
      value: []
    });
  }

  addParamTosqlParamatersFormArray() {
    this.sqlParamatersFormArray.push(this.createFilterGroup());
  }
  removeParamFromsqlParamatersFormArray(index) {
    this.sqlParamatersFormArray.removeAt(index);
  }
  selectedAPIChanged(i) {
    this.getFilterGroupAtIndex(i).addControl('value', this.getFormControl());
  }
  getFormControl() {
    return this.formBuilder.control(null);
  }
  get sqlParamatersFormArray() {
    return (<FormArray>this.secondFormGroup.get('sqlparameters'));
  }
  getFilterGroupAtIndex(index) {
    return (<FormGroup>this.sqlParamatersFormArray.at(index));
  }
  clear(index: number) {
    this.input = null;
    this.questionText = null;
    this.uniqueId = null;
    this.stepper.selectedIndex = index;
    this.firstFormGroup.reset();
    this.secondFormGroup.reset();
  }

  showValues() {
    console.log('User Values' + this.query.sql);
    console.log('User Values' + this.query.description);

    this.queryService.getQueryById('2').subscribe(data => this.queryList = data);
    console.log('firstFormGroup: queryList/Dynamic Form Value' + this.queryList + '/' + this.firstFormGroup);
    console.log('secondFormGroup: queryList/Dynamic Form Value' + this.queryList + '/' + this.secondFormGroup);
  }
}
