import { SelectionModel } from '@angular/cdk/collections';
import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSnackBarConfig, MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { QueryList } from '../models/QueryList';
import { QueryService } from '../services/query.service';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';

@Component({
  selector: 'app-query-result',
  templateUrl: './query-result.component.html',
  styleUrls: ['./query-result.component.css']
})
export class QueryResultComponent implements OnInit {
  dataSource:any; //= new MatTableDataSource(this.queryList);
  originalDataSource:any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

  public selection = new SelectionModel<any>(true, []);

  length = 100;
  pageSize = 10;
  pageSizeOptions: number[] = [5, 10, 25, 100];
  tableData:any = [];
  tableColumns: string[]=[];
  inputQuery!: QueryList;
  queryName: string='';
  isSelect!: boolean;
  rowsAffected: string='';
  isError: string='';
  errorMessage: string='';
  showTable!: boolean;
  isDataAVailable!: boolean;
  isExportAllowed: boolean = false;
  public isLoading = true;
  public isTimeout = false;
  error = 'Timeout Error Occured';

  private config = new MatSnackBarConfig();

  csvoptions = {
    fieldSeparator: ',',
    quoteStrings: '"',
    decimalSeparator: '.',
    showLabels: true,
    showTitle: true,
    title: 'Query Resultset Export',
    useTextFile: false,
    useBom: true,
    headers: []// <-- Won't work with useKeysAsHeaders present!
  };

  // MatPaginator Output
  pageEvent!: PageEvent;
  constructor(
    private queryService: QueryService,
    private snackBar: MatSnackBar,
    private datepipe: DatePipe,
    public activeModal: NgbActiveModal,
    public queryResultDialogRef: MatDialogRef<QueryResultComponent>,
  ) { }

  ngOnInit(): void {

    this.inputQuery = this.queryService.getQueryInputParams();

    console.log('Query Result Component');
    console.log(JSON.stringify(this.inputQuery));

    this.queryName = this.inputQuery.name;
    const user = JSON.parse(sessionStorage.getItem('currentUser')||"{}");

    this.queryService.executeQuery(this.inputQuery, user.userName).subscribe((response:any) => {
      this.tableColumns = response.headers;
      this.csvoptions.headers = (this.tableColumns as any);// check here

      this.rowsAffected = response.rowsAffected;
      this.isError = response.isError;
      this.errorMessage = response.errorMessage;

      for (let rownum in response.data) {
        this.tableData.push(response.data[rownum].element);
      }
      this.dataSource = new MatTableDataSource(this.tableData);
      this.originalDataSource = this.dataSource;
      this.dataSource.sort = this.sort;
      this.isLoading = false;
      this.isTimeout = false;

      if (response.data !== undefined && response.data.length > 0) {
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.showTable = true;
        this.isDataAVailable = false;

        if (user.exportAllowed) { this.isExportAllowed = true; }

      } else {
        this.dataSource.paginator = this.paginator;
        this.showTable = false;
        this.isDataAVailable = true;
        this.isExportAllowed = false;
      }

      if (this.isError.length > 5) {
        let msg: string;
        msg = this.isError;
        if (user.addQueryAllowed) {
          msg = this.errorMessage;
        } else { msg = 'Error occured, please contact your administrator' }
        this.openQuerySnackbar('red', msg);
        this.closeModal();
      }
    },
      err => {
        console.log(err);
        if (err.includes(429)) {
          this.openQuerySnackbar('red', 'too many requests, please try again after your current requests complete');
        } else {
          this.openQuerySnackbar('red', 'Query encountered unexpected error, please contact admin');
        }
        this.closeModal();
        this.isLoading = false;
        this.isTimeout = true;
      });
  }

  closeModal() {
    this.queryResultDialogRef.close();
  }
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ? this.selection.clear() : this.dataSource.data.forEach((row:any) => this.selection.select(row));
  }

  downloadCSV() {
    const queryName = this.inputQuery.name;
    const date = this.datepipe.transform(new Date(), '_dd.MMM.yy_HH.mm.ss a');
    const user = JSON.parse(sessionStorage.getItem('currentUser')||"{}");
    this.downloadUtility(this.inputQuery, queryName + '_' + date + '.csv', 'downloadCSV?racfId=' + user.userName);
  }

  values: string[]=[];
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  filterText: string[] = [];

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    console.log(this.values);
  }

  // Add chip input to the array for filter
  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;
    if ((value || '').trim()) {
      this.filterText.push(value.trim());
    }
    // Reset the input value
    console.log(value);
    if (input) {
      input.value = '';
    }
    console.log('After adding', this.filterText);
    this.filterTable(this.filterText);
  }

  // remove chip inputs from the array for filter
  remove(filter: string): void {
    const index = this.filterText.indexOf(filter);
    if (index >= 0) {
      this.filterText.splice(index, 1);
    }
    console.log('After Removing', this.filterText);
    this.dataSource = this.originalDataSource;
    this.dataSource.filter = '';
    this.filterTable(this.filterText);
  }

  tempDataSource: any;

  filterTable(filterArray: string[]) {
    for (let filterStr of filterArray) {
      this.dataSource.filter = filterStr.trim().toLowerCase();
      this.tempDataSource = this.dataSource;
      console.log('tempDataSource', this.tempDataSource)
      console.log('dataSource', this.dataSource)
    }
  }

  openQuerySnackbar(color: string, message?: string): void {
    this.config.duration = 4000;
    this.config.panelClass = [color + '-snackbar']
    this.config.horizontalPosition = 'end',
      this.config.verticalPosition = 'top'
    this.snackBar.open(message||"", 'Dismiss', this.config);
  }

  copyToClipboard() {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.innerText = this.inputQuery.sql;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
    this.openQuerySnackbar('darkGray', 'query copied to your clipboard');
  }

  downloadExcel() {
    const queryName = this.inputQuery.name;
    const date = this.datepipe.transform(new Date(), '_dd.MMM.yy_HH.mm.ss a');
    const user = JSON.parse(sessionStorage.getItem('currentUser')||"{}");
    this.downloadUtility(this.inputQuery, queryName + '_' + date + '.xls', 'downloadExcel?racfId=' + user.userName);
  }

  downloadUtility(result: QueryList, fileName: string, requestURI: string) {
    this.queryService.downloadData(result, requestURI).subscribe(response => {

      // console.log(window.navigator.msSaveOrOpenBlob);

      if ((window.navigator as any).msSaveOrOpenBlob) {// check here
        // msSaveBlob only available for IE & Edge
        (window.navigator as any).msSaveBlob(response, fileName);
      } else { //fr other browsers 
        let dwldLink = document.createElement('a');
        let url = URL.createObjectURL(response);
        let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
        if (isSafariBrowser) {
          dwldLink.setAttribute('target', '_blank');
        }
        dwldLink.setAttribute('href', url);
        dwldLink.setAttribute('download', fileName);
        dwldLink.style.visibility = 'hidden';
        document.body.appendChild(dwldLink);
        dwldLink.click();
        document.body.removeChild(dwldLink);
      }

    }), (error: any) => console.log('Error downloading the file'),
      () => console.info('File downloaded successfully');
  }
}