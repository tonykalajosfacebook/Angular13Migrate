import { trigger, transition, style, animate } from '@angular/animations';
import { DatePipe } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { QueryList, QueryParameters } from '../models/QueryList';
import { QueryService } from '../services/query.service';

@Component({
  selector: 'app-query-param-input',
  templateUrl: './query-param-input.component.html',
  styleUrls: ['./query-param-input.component.css'],
  animations: [
    trigger('slideInOut', [
      transition(':enter', [
        style({ transform: 'translateY(-100%)' }),
        animate(500, style({ height: 0 }))
      ]),
      transition(':leave', [
        animate(500, style({ height: 100 }))
      ])
    ])
  ]
})
export class QueryParamInputComponent implements OnInit {

  @Input() queryParams: QueryParameters[] = [];
  @Input() executionComments: string = "";
  @Input() queryList!: QueryList;

  isSelectQuery!: boolean;
  isQueryParameterized!: boolean;
  public queryResultDialogRef!: MatDialogRef<QueryParamInputComponent>;

  constructor(
    public activeModal: NgbActiveModal,
    private datepipe: DatePipe,
    private queryService: QueryService,
  ) { }


  ngOnInit(): void {
    this.isQueryParameterized = this.queryList.parameterized === 'Y' ? true : false;
    this.isSelectQuery = this.queryList.sql != null && this.queryList.ddlDml === "sel" ? true : false;
  }
  onSearchChange(e: any): void {
    // onSearchChange(searchValue: string): void {
    // use `e.target.value` to access value

  }

  sendQueryParams() {
    this.queryList.parameters = this.queryParams;
    this.queryList.executionComments = this.executionComments;
    this.activeModal.close(this.queryList);
  }

  closeModal() {
    this.activeModal.dismiss();
  }

  downloadCSV() {
    this.queryList.parameters = this.queryParams;
    this.queryList.executionComments = this.executionComments;
    const queryName = this.queryList.name;
    const date = this.datepipe.transform(new Date(), '_dd.MMM.yy_HH.mm.ss a');
    const user = JSON.parse(sessionStorage.getItem('currentUser') || "{}");// check here
    this.downloadData(this.queryList, queryName + '_' + date + '.csv', 'downloadCSV?racfId=' + user.userName);
    this.activeModal.dismiss();
  }

  downloadExcel() {
    this.queryList.parameters = this.queryParams;
    this.queryList.executionComments = this.executionComments;
    const queryName = this.queryList.name;
    const date = this.datepipe.transform(new Date(), '_dd.MMM.yy_HH.mm.ss a');
    const user = JSON.parse(sessionStorage.getItem('currentUser') || "{}");// check here
    this.downloadData(this.queryList, queryName + '_' + date + '.xls', 'downloadExcel?racfId=' + user.userName);
    this.activeModal.dismiss();
  }

  downloadData(result: QueryList, fileName: string, requestURI: string) {
    this.queryService.downloadData(result, requestURI).subscribe(response => {

      if ((window.navigator as any).msSaveOrOpenBlob) { // check here
        (window.navigator as any).msSaveBlob(response, fileName); // IE & Edge
      } else {
        const dwldLink = document.createElement('a');
        const url = URL.createObjectURL(response);
        const isSafariBrowser = navigator.userAgent.indexOf('Safari') !== -1 && navigator.userAgent.indexOf('Chrome') === -1;
        if (isSafariBrowser) {  // if Safari open in new window to save file with random filename.
          dwldLink.setAttribute('target', '_blank');
        }
        dwldLink.setAttribute('href', url);
        dwldLink.setAttribute('download', fileName);
        dwldLink.style.visibility = 'hidden';
        document.body.appendChild(dwldLink);
        dwldLink.click();
        document.body.removeChild(dwldLink);
      }
    }), (error: any) => console.log('Error downloading the file'),
      () => console.info('File downloaded successfully');
  }
}