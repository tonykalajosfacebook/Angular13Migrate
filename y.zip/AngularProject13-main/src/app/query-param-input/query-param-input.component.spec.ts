import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QueryParamInputComponent } from './query-param-input.component';

describe('QueryParamInputComponent', () => {
  let component: QueryParamInputComponent;
  let fixture: ComponentFixture<QueryParamInputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QueryParamInputComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QueryParamInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
