import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ToolGroupsComponent } from './tool-groups.component';

describe('ToolGroupsComponent', () => {
  let component: ToolGroupsComponent;
  let fixture: ComponentFixture<ToolGroupsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ToolGroupsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ToolGroupsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
