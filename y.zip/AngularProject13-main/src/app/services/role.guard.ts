import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {

  constructor(public router: Router) { }

  canActivate(routerSnapshot: ActivatedRouteSnapshot): boolean {
    let user: User = JSON.parse(sessionStorage.getItem('currentUser') || "{}");// check here
    let path = routerSnapshot.data['path'];
    if (user && user.userName) {
      let userRole = user.role;
      if (user.role === "USER" && path == "ViewUser") {
        this.router.navigate(['/query']);
        return false;
      }
      else if (user.role === "USER" && path == "AddUser") {
        this.router.navigate(['/query']);
        return false;
      }
      else if ((user.role === "USER" || user.role === "GROUP_ADMIN") && path == "ViewGroups") {
        this.router.navigate(['/query']);
        return false;
      }
      else if ((user.role === "USER" || user.role === "GROUP_ADMIN") && path == "AddGroups") {
        this.router.navigate(['/query']);
        return false;
      }
      else {
        return true;
      }
    } else {
      this.router.navigate(['/login']);
      return false;
    }
  }

}
