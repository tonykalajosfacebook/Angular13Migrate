import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(public router: Router) { }

  canActivate(): boolean {
    let user: User = JSON.parse(sessionStorage.getItem('currentUser') || "{}");
    console.log(user);
    
    // return true; for testing log
    if (user && user.userName) {
      return true;
    } else {
      this.router.navigate(['/login']);
      return false;
    }
  }

}
