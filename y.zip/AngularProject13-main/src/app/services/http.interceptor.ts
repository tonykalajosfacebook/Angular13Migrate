import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class BaseUrlInterceptor implements HttpInterceptor {
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    console.log('user-->', JSON.parse(sessionStorage.getItem('currentUser') || "{}"))

    const apiReq = req.clone({
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'environment': sessionStorage.getItem('environment') ? sessionStorage.getItem('environment') || "" : '',// check here
        'userId': sessionStorage.getItem('currentUser') ? JSON.parse(sessionStorage.getItem('currentUser') || "{}").userName : ''//check here
      })
    });
    return next.handle(apiReq);
  }
}