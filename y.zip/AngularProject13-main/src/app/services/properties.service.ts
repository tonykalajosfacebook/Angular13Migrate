import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { Properties } from '../models/properties';

@Injectable({
  providedIn: 'root'
})
export class PropertiesService {
  static properties: Properties;
  constructor(private http: HttpClient) { }

  initializeProperties() {
    // check here
    return this.http.get('api/properties').pipe(map((properties: any) => {
      PropertiesService.properties = properties;
    })).toPromise();
  }
}
