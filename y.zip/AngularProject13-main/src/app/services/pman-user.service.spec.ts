import { TestBed } from '@angular/core/testing';

import { PmanUserService } from './pman-user.service';

describe('PmanUserService', () => {
  let service: PmanUserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PmanUserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
