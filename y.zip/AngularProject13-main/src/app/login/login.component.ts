import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MessageService } from 'primeng/api';
import { CommonNotifyModalComponent } from '../common-components/common-notify-modal/common-notify-modal.component';
import { User } from '../models/user';
import { PmanUserService } from '../services/pman-user.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [MessageService]
})
export class LoginComponent implements OnInit {

  public loaderLoading = false;
  loading = false;
  showTable = true;
  error = '';
  notRegistered = false;
  public submitted = false;
  userRoute: string = '';
  advancedSearchQuery = '';
  public myForm: FormGroup = new FormGroup({});
  public loginForm: FormGroup = new FormGroup({});
  commonAlertsComponent!: CommonNotifyModalComponent;
  environments: string[] = [];
  selectedEnvironment: string = '';

  constructor(private router: Router, private formBuilder: FormBuilder,
    private userService: UserService,
    private pmanUserService: PmanUserService,
    private modalService: NgbModal
  ) { }

  ngOnInit(): void {
    const user = JSON.parse(sessionStorage.getItem('currentUser') || "{}");

    if (user) {
      this.router.navigate(['/query']);
    } else {
      this.pmanUserService.getDBEnvironments().subscribe((res: any) => {
        this.environments = res;
        this.selectedEnvironment = res[0];
        sessionStorage.setItem('environment', this.selectedEnvironment);
      });
    }
    this.loginForm = this.formBuilder.group({
      userName: ['', Validators.required],
      password: ['', Validators.required]
    });
    this.myForm = this.formBuilder.group({
      text1: ['', Validators.required]
    });
  }

  get loginImage() {
    return '../../assets/images/logo.png';
  }

  onChange() {
    this.showTable = false;
  }
  setEnvironment(e: any) {
    // check here major
    console.log('value of env', e.target.value);
    sessionStorage.setItem('environment', e.target.value);
  }

  get f() { return this.loginForm.controls; }

  login(user: User) {
    this.loading = true;
    this.submitted = true;

    if (this.loginForm.invalid) {
      this.loading = false;
      return;
    }

    this.userService.login(user.userName, user.password)
      .subscribe(userd => {

        this.loading = false;
        this.router.navigate(['/query']);
        this.submitted = false;
      },
        err => {
          this.submitted = false;
          this.loading = false;
          if (err.status === 403) {
            this.error = 'User not authorized to access Support Tool';
            this.openDialog(this.error);
          } else if (err.status === 409) {
            this.error = 'Please request access to the AD group of your application';
          } else if (err.status === 401) {
            this.error = 'Incorrect username/Password';
          } else if (err.status === 400) {
            this.error = 'User doesnt Exist in the selected Database.\n Please submit access using GetIT.';
          } else if (err.status) {
            this.error = 'Well, this is embarassing. \n We are facing some issues : Error ' + err.status
              + '. But don\'t lose hope! we will be back shortly. ';
          } else {
            this.error = 'Well, this is embarassing.\n We are facing some issues. But don\'t lose hope! we will be back shortly.';
          }
          this.openDialog(this.error);
        });
  }

  openDialog(message: string) {

    const dialogRef = this.modalService.open(CommonNotifyModalComponent, { centered: true });
    dialogRef.componentInstance.title = 'Oh no!';
    dialogRef.componentInstance.message = message;
    dialogRef.componentInstance.btnOkText = 'I under Stand';

  }
  //  openFactorySignUpModal() {
  //    const modalRef = this.modalService.open(FactorySignUpComponent, { centered: true, size: 'lg' });
  //  }
}
