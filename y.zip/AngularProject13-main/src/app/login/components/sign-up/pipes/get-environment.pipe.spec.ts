import { GetEnvironmentPipe } from './get-environment.pipe';

describe('GetEnvironmentPipe', () => {
  it('create an instance', () => {
    const pipe = new GetEnvironmentPipe();
    expect(pipe).toBeTruthy();
  });
});
