import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-common-notify-modal',
  templateUrl: './common-notify-modal.component.html',
  styleUrls: ['./common-notify-modal.component.css']
})
export class CommonNotifyModalComponent implements OnInit {
  @Input() title: string = "";
  @Input() message: string = "";
  @Input() btnOkText: string = "";

  constructor(private activeModal: NgbActiveModal) { }

  ngOnInit() {
  }

  public decline() {
    this.activeModal.close(false);
  }

  public accept() {
    this.activeModal.close(true);
  }

  public dismiss() {
    this.activeModal.dismiss();
  }
}
