export interface Query {
  id: string;
  name: string;
  description: string;
  sql: string;
  queryHelpLink: string;
  selectedGroups: string[];
  parameters: Parameter[];
  isError?: boolean;
	errorMessage?: string;
}

export interface SelectedGroups {
  value: string;
  viewValue: string;
}

export interface Parameter {
  id: string;
  orderId: string;
  name: string;
  dataType: string;
  value: string;
}