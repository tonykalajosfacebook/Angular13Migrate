export class Properties {
    serverEnvironment: string;
}
