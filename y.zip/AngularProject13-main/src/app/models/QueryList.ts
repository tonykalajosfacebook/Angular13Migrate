export interface QueryList {
    id: string;
    name: string;
    description: string;
    sql: string;
    parameterized: string;
    groupAllowed: string;
    groupList: string[];
    selectedGroups: SelectedGroups[];
    associatedGroup: string;
    nbrOfParameters: string;
    parameters: QueryParameters[];
    executionComments: string
    ddlDml: string;
    queryHelpLink: string;
  }

  export interface SelectedGroups {
    value: string;
    viewValue: string;
  }

  export interface QueryParameters {
    id: string;
    orderId: string;
    name: string;
    dataType: string;
    value: string;
  }