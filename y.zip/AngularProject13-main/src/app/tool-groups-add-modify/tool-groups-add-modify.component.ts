import { trigger, transition, style, animate } from '@angular/animations';
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { NgForm, FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToolGroups } from '../models/ToolGroups';
import { ToolGroupsService } from '../services/tool-groups.service';

@Component({
  selector: 'app-tool-groups-add-modify',
  templateUrl: './tool-groups-add-modify.component.html',
  styleUrls: ['./tool-groups-add-modify.component.css'],
  encapsulation: ViewEncapsulation.None,
  animations: [
    trigger('slideInOut', [
      transition(':enter', [
        style({ transform: 'translateY(-100%)' }),
        animate(500, style({ height: 0 }))
      ]),
      transition(':leave', [
        animate(500, style({ height: 100 }))
      ])
    ])
  ]
})
export class ToolGroupsAddModifyComponent implements OnInit {

  toolGroups: ToolGroups = { id: "", name: '', description: '' };
  allToolGroups: ToolGroups[] = [];
  existingToolGroups: string[] = [];
  id: string = "";
  formErr!: boolean;
  flowTypeCreate!: boolean;
  isReadOnly!: boolean;
  @ViewChild('toolGroupForm') toolGroupForm!: NgForm;
  groupsFormGroup: FormGroup = new FormGroup({});
  isDropDownEnabled!: boolean;

  constructor(private toolGroupService: ToolGroupsService,
    private activatedRoute: ActivatedRoute,
    private snackBar: MatSnackBar,
    public activeModal: NgbActiveModal,
    public formBuilder: FormBuilder,
  ) {
    this.activatedRoute.paramMap.subscribe(params => {
      this.id = params.get('id') || "";// check here
    });
  }

  ngOnInit(): void {
    this.id = sessionStorage.getItem('tool-groups-GroupID') || "";// check here
    console.log('tool-groups-GroupID passed to modal' + sessionStorage.getItem('tool-groups-GroupID'));

    this.fetchAllToolGroups();
    if (this.id != null && this.id !== 'NewRecordRequest') {
      this.initializeToolGroupById(this.id);
      this.flowTypeCreate = false;
      this.isReadOnly = true;
    } else {
      this.initializeToolGroup();
      this.flowTypeCreate = true;
      this.isReadOnly = false;
      this.isDropDownEnabled = false;
    }

    this.groupsFormGroup = this.formBuilder.group({
      nameFormControl: new FormControl('', [Validators.required, Validators.minLength(8)]),
      descriptionFormControl: new FormControl('', [Validators.required, Validators.minLength(8)]),
      groupsFormControl: new FormControl([''])
    });
  }

  ngAfterViewInit() {
    this.toolGroupForm.form.valueChanges.subscribe(x => {
      this.formErr = false;
    });
  }

  initializeToolGroup() {
    this.toolGroupService.getToolGroup().subscribe(response => {
      console.log(response);
      this.toolGroups = response;
      this.toolGroups.name = '';
      this.toolGroups.description = '';

      console.log('ToolGroups', this.toolGroups);
    });
  }

  initializeToolGroupById(id: string) {
    this.toolGroupService.getToolGroupById(id).subscribe(response => {
      this.toolGroups = response;
      this.isDropDownEnabled = true;

      this.groupsFormGroup.get('nameFormControl')?.setValue(this.toolGroups.name);
      this.groupsFormGroup.get('descriptionFormControl')?.setValue(this.toolGroups.description);
    });
  }

  getToolGroupById(groupId: String) {
    this.toolGroupService.getToolGroupById(groupId).subscribe(response => {
      console.log('will try to set nameFormControl to' + this.toolGroups.name);
      this.toolGroups = response;
    });
  }

  fetchAllToolGroups() {
    const user = JSON.parse(sessionStorage.getItem('currentUser') || "{}");// check here
    this.toolGroupService.getAllToolGroups(true, true).then(
      response => {
        this.allToolGroups = response;
        this.existingToolGroups = response.map(a => a.name);
        console.log('existing toolGroups/user: ', this.existingToolGroups + '/' + user);
      }
    );
  }

  createToolGroup() {

    const config = new MatSnackBarConfig();
    config.duration = 4000;
    config.panelClass = ['red-snackbar']
    config.horizontalPosition = 'end',
      config.verticalPosition = 'top'

    this.toolGroups.name = this.groupsFormGroup.get('nameFormControl')?.value;
    this.toolGroups.description = this.groupsFormGroup.get('descriptionFormControl')?.value;

    if (this.flowTypeCreate && this.existingToolGroups.includes(this.toolGroups.name)) {
      this.formErr = true;
      this.snackBar.open('This groupname already exist', 'Error', config);
    } else {
      this.toolGroupService.createToolGroup(this.toolGroups).subscribe(response => {
        config.panelClass = ['green-snackbar']
        this.toolGroups = response;
        if (this.flowTypeCreate) {
          this.snackBar.open('Group Name: ' + response.name + '  is created', 'Success', config);
        } else {
          this.snackBar.open('Group Name: ' + response.name + '  is updated', 'Success', config);
        }
        this.activeModal.close('success');
      });
    }
  }

  clearForm() {
    this.toolGroups.id = '';
    this.toolGroups.name = '';
    this.toolGroups.description = '';
    this.formErr = false;
  }

  closeModal() {
    this.activeModal.dismiss();
  }
}