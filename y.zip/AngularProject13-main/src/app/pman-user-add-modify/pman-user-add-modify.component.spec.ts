import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PmanUserAddModifyComponent } from './pman-user-add-modify.component';

describe('PmanUserAddModifyComponent', () => {
  let component: PmanUserAddModifyComponent;
  let fixture: ComponentFixture<PmanUserAddModifyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PmanUserAddModifyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PmanUserAddModifyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
