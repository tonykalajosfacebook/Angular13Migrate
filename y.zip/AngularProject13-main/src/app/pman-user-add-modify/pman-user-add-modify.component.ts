import { animate, style, transition, trigger } from '@angular/animations';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatStepper } from '@angular/material/stepper';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { PmanUser } from '../models/PmanUser';
import { ToolGroups } from '../models/ToolGroups';
import { PmanUserService } from '../services/pman-user.service';
import { ToolGroupsService } from '../services/tool-groups.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-pman-user-add-modify',
  templateUrl: './pman-user-add-modify.component.html',
  styleUrls: ['./pman-user-add-modify.component.css'],
  animations: [
    trigger('slideInOut', [
      transition(':enter', [
        style({ transform: 'translateY(-100%)' }),
        animate(500, style({ height: 0 }))
      ]),
      transition(':leave', [
        animate(500, style({ height: 100 }))
      ])
    ])
  ]
})
export class PmanUserAddModifyComponent implements OnInit {
  dataSource: any;
  public isLoading = true;
  allToolGroups: ToolGroups[] = [];
  availableGroupIds: string[] = [];
  availableAdminGroupIds: string[] = [];
  availableGroupNames: string[] = [];
  availableAdminGroupNames: string[] = [];
  availableActionNames: string[] = [];
  selectedGroupNames: string[] = [];
  selectedAdminGroupNames: string[] = [];
  selectedActionNames: string[] = [];
  selectedGroupIds: string[] = [];
  selectedAdminGroupIds: string[] = [];
  selectedActionIds: string[] = [];
  initializedPmanUser!: PmanUser;
  userId: string = '';
  racfId: string = '';
  id: string = '';
  selectedRole: string = '';
  userNames: string[] = [];
  InValidUsernput: boolean = false;
  formUserNameErr: boolean = false;
  formSelectedRoleErr: boolean = false;
  formUserGroupsErr: boolean = false;
  formUserAdminGroupsErr: boolean = false;
  formUserActionsErr: boolean = false;
  adminGroupsErrMsg: string = '';
  flowType: string = 'Created';
  isUser!: boolean;
  adminUserCreationAllowed: boolean = false;

  firstFormGroup: FormGroup = new FormGroup({});
  secondFormGroup: FormGroup = new FormGroup({});
  thirdFormGroup: FormGroup = new FormGroup({});
  fourthFormGroup: FormGroup = new FormGroup({});
  fifthFormGroup: FormGroup = new FormGroup({});

  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild('stepper') stepper!: MatStepper;

  constructor(
    private router: Router,
    private pmanUserService: PmanUserService,
    private toolGroupsService: ToolGroupsService,
    private userService: UserService,
    private snackbar: MatSnackBar,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    public activeModal: NgbActiveModal,
  ) { }

  ngOnInit(): void {
    this.initializeCreateUpdateUserForm();
    this.getAllUsers();
    this.setPrivilege();

    this.firstFormGroup = this.formBuilder.group({
      racfIdFormControl: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(10)]),
      selectedRoleFormControl: new FormControl('', [Validators.required])
    });

    this.secondFormGroup = this.formBuilder.group({
      selectedGroupsFormControl: new FormControl('', [Validators.required]),
      selectedAdminGroupsFormControl: new FormControl('')
    });

    this.thirdFormGroup = this.formBuilder.group({
      selectedActionsFormControl: new FormControl('', [Validators.required])
    }
    );
  }

  setPrivilege() {
    const user = JSON.parse(sessionStorage.getItem('currentUser') || "{}");// check here
    this.adminUserCreationAllowed = user.adminUserCreationAllowed;
  }

  initializeCreateUpdateUserForm() {
    this.id = window.sessionStorage.getItem('user-userID') || "";

    this.toolGroupsService.getAllToolGroups(true, true).then(response => {
      this.allToolGroups = response;
    });

    if (this.id !== null && this.id !== 'NewRecordRequest') {
      this.initializeUpdateUserForm(this.id);
      this.flowType = 'Updated';
    } else {
      this.initializeCreateUserForm();
      this.flowType = 'Created';
    }
    window.sessionStorage.setItem('user-userID', "");// check here
    console.log('user-userID:' + this.id + '/flowType:' + this.flowType);
  }

  initializeCreateUserForm() {
    const user = JSON.parse(sessionStorage.getItem('currentUser') || "{}"); // check here
    this.isUser = user.role === 'USER' ? true : false;
    this.pmanUserService.getUserGroupsForCreateUser(user.userName).subscribe((data: any) => {
      this.initializedPmanUser = data;
      console.log('Create Users Object', this.initializedPmanUser);

      for (const group of data.availableGroups) {
        this.availableGroupNames.push(group.name);
      }
      for (const adminGroup of data.availableAdminGroups) {
        this.availableAdminGroupNames.push(adminGroup.name);
      }
      for (const action of data.availableActions) {
        this.availableActionNames.push(action.name);
      }
    });
  }

  initializeUpdateUserForm(racfId: string) {
    const user = JSON.parse(sessionStorage.getItem('currentUser') || "{}");
    this.isUser = user.role === 'USER' ? true : false;

    this.pmanUserService.getUserGroupsforUpdateUser(user.userName, racfId).subscribe((data: any) => {
      this.initializedPmanUser = data;
      console.log('Update Users' + user + '  Object', this.initializedPmanUser);
      this.initializedPmanUser.userId = data.userId;
      this.initializedPmanUser.racfId = data.racfId;

      this.roleChange(data.selectedRole);
      this.selectedGroupIds = data.selectedGroups.split(',');
      this.selectedAdminGroupIds = data.selectedAdminGroups.split(',');
      this.selectedActionIds = data.selectedActions.split(',');

      for (const group of this.allToolGroups) {
        if (this.selectedGroupIds.includes(group.id.toString())) {
          this.selectedGroupNames.push(group.name);
        }
        if (this.selectedAdminGroupIds.includes(group.id.toString())) {
          this.selectedAdminGroupNames.push(group.name);
        }
      }
      for (const group of data.availableGroups) {
        this.availableGroupIds.push(group.id.toString());
        this.availableGroupNames.push(group.name);
      }
      for (const adminGroup of data.availableAdminGroups) {
        this.availableAdminGroupIds.push(adminGroup.id.toString());
        this.availableAdminGroupNames.push(adminGroup.name);
      }
      for (const action of data.availableActions) {
        this.availableActionNames.push(action.name);
        if (this.selectedActionIds.includes(action.id.toString())) {
          this.selectedActionNames.push(action.name);
        }
      }

      this.firstFormGroup.get('racfIdFormControl')?.setValue(data.racfId);
      this.firstFormGroup.controls['racfIdFormControl'].disable();
      this.firstFormGroup.get('selectedRoleFormControl')?.setValue(data.selectedRole);
      this.secondFormGroup.get('selectedGroupsFormControl')?.setValue(this.selectedGroupNames);
      this.secondFormGroup.get('selectedAdminGroupsFormControl')?.setValue(this.selectedAdminGroupNames);
      this.thirdFormGroup.get('selectedActionsFormControl')?.setValue(this.selectedActionNames);
    });
  }

  async getAllUsers() {
    const user = JSON.parse(sessionStorage.getItem('currentUser') || "{}");
    this.pmanUserService.getAllPmanUsers(user.userName, true).then(
      response => {
        console.log('Pman Users Response -->>>>' + response);
        for (const user of response) {
          this.userNames.push(user.racfId);
        }
        this.dataSource = new MatTableDataSource(response);
        this.dataSource.paginator = this.paginator;
        this.isLoading = false;
      }
    );
  }

  createPmanUser() {
    const user = JSON.parse(sessionStorage.getItem('currentUser') || "{}");
    const config = new MatSnackBarConfig();
    config.duration = 4000;
    config.panelClass = ['red-snackbar']
    config.horizontalPosition = 'end',
      config.verticalPosition = 'top'

    this.initializedPmanUser.selectedRole = this.firstFormGroup.value.selectedRoleFormControl;
    const selectedGroups: string[] = [];
    const selectedAdminGroups: string[] = [];
    const selectedActions: string[] = [];

    this.validateUserInput();
    if (!this.initializedPmanUser.racfId) { this.InValidUsernput = true; return; }
    if (this.userNames.includes(this.initializedPmanUser.userId)) { this.formUserNameErr = true; return; }
    if (!this.initializedPmanUser.selectedRole) { this.formSelectedRoleErr = true; return; }

    if (user.role == "ADMIN") {
      if (this.displayGroups) {
        for (const group of this.allToolGroups) {
          if (this.secondFormGroup.value.selectedGroupsFormControl.includes(group.name)) {
            selectedGroups.push(group.id.toString());
          }
        }
        if (selectedGroups.length === 0) {
          this.formUserGroupsErr = true;
          return;
        }
        this.initializedPmanUser.selectedGroups = selectedGroups.join(',');
      }

      if (this.displayGroupAdminGroups) {

        for (const group of this.allToolGroups) {
          if (this.secondFormGroup.value.selectedAdminGroupsFormControl.includes(group.name)) {
            selectedAdminGroups.push(group.id.toString());
          }
        }
        if (selectedAdminGroups.length === 0) {
          this.formUserAdminGroupsErr = true;
          this.adminGroupsErrMsg = 'Please select at least one Admin Group';
          return;
        }
        if (selectedAdminGroups.length !== 0) { this.initializedPmanUser.isGroupAdmin = 'Y'; }

        this.initializedPmanUser.selectedAdminGroups = selectedAdminGroups.join(',');

        const commonGroups = selectedAdminGroups.filter(function (v) { return selectedGroups.indexOf(v) > -1; });

        if (commonGroups.length === 0) {
          config.panelClass = ['red-snackbar'];
          this.snackbar.open('Please select at least one AdminGroup in Common with the selected Groups', 'Error', config);
          this.adminGroupsErrMsg = 'Attention Needed';
          this.formUserAdminGroupsErr = true;
          return;
        }

        for (const action of this.initializedPmanUser.availableActions || []) {// check here
          if (this.thirdFormGroup.value.selectedActionsFormControl.includes(action.name)) {
            selectedActions.push(action.id.toString());
          }
        }
        if (selectedActions.length === 0) {
          this.formUserActionsErr = true;
          return;
        }
        this.initializedPmanUser.selectedActions = selectedActions.join(',');
      }
    }

    // Validate GroupAdmin Related inputs ONLY If Role is GroupAdmin i.e GroupAdmin Panel is visible
    if (user.role == "GROUP_ADMIN") {
      if (this.selectedGroupIds.length != 0) {
        for (const groupId of this.selectedGroupIds) {
          if (!this.availableGroupIds.includes(groupId)) {
            selectedGroups.push(groupId);
          }
        }
      }
      for (const group of this.allToolGroups) {
        if (this.availableGroupNames.includes(group.name)) {
          if (this.secondFormGroup.value.selectedGroupsFormControl.includes(group.name)) {
            selectedGroups.push(group.id.toString());
          }
        }
      }
      if (selectedGroups.length === 0) {
        this.formUserGroupsErr = true;
        return;
      }
      this.initializedPmanUser.selectedGroups = selectedGroups.join(',');

      if (this.selectedAdminGroupIds.length != 0) {
        for (const adminGroupId of this.selectedAdminGroupIds) {
          if (!this.availableAdminGroupIds.includes(adminGroupId)) {
            selectedAdminGroups.push(adminGroupId);
          }
        }
      }

      if (this.displayGroupAdminGroups) {

        for (const group of this.allToolGroups) {
          if (this.availableAdminGroupNames.includes(group.name)) {
            if (this.secondFormGroup.value.selectedAdminGroupsFormControl.includes(group.name)) {
              selectedAdminGroups.push(group.id.toString());
            }
          }
        }
        if (selectedAdminGroups.length === 0) {
          this.formUserAdminGroupsErr = true;
          this.adminGroupsErrMsg = 'Please select at least one Admin Group';
          return;
        }
        if (selectedAdminGroups.length !== 0) { this.initializedPmanUser.isGroupAdmin = 'Y'; }

        this.initializedPmanUser.selectedAdminGroups = selectedAdminGroups.join(',');

        const commonGroups = selectedAdminGroups.filter(function (v) { return selectedGroups.indexOf(v) > -1; });

        if (commonGroups.length === 0) {
          config.panelClass = ['red-snackbar'];
          this.snackbar.open('Please select at least one AdminGroup in Common with the selected Groups', 'Error', config);
          this.adminGroupsErrMsg = 'Attention Needed';
          this.formUserAdminGroupsErr = true;
          return;
        }

        for (const action of this.initializedPmanUser.availableActions || []) {// check here
          if (this.thirdFormGroup.value.selectedActionsFormControl.includes(action.name)) {
            selectedActions.push(action.id.toString());
          }
        }
        if (selectedActions.length === 0) {
          this.formUserActionsErr = true;
          return;
        }
        this.initializedPmanUser.selectedActions = selectedActions.join(',');
      }
    }

    this.pmanUserService.createUser(this.initializedPmanUser).subscribe((data: any) => {
      console.log('Create User Executed');
      console.log(data);
      if (data.error) {
        this.snackbar.open(data.errorMessage, '', config);
      } else {
        config.panelClass = ['green-snackbar'];
        this.snackbar.open('User ' + this.flowType + ' Successfully. ' + 'UserId : ' + data.racfId, 'Success', config);
        this.activeModal.close('success');

        if (this.initializedPmanUser.racfId == user.userName) {
          sessionStorage.removeItem('currentFactory');
          sessionStorage.removeItem('environment');
          this.router.navigate(['/login']);
          this.userService.logout();
        }
      }
    });
  }

  displayGroups: boolean = false;
  displayGroupAdminGroups: boolean = false;
  displayActions: boolean = false;
  openedGroupsPanel: boolean = false;
  openedAdminGroupsPanel: boolean = false;
  openedActionPanel: boolean = false;

  resetForm(index: number) {
    this.formSelectedRoleErr = false;
    this.formUserGroupsErr = false;
    this.formUserAdminGroupsErr = false;
    this.formUserActionsErr = false;
    window.sessionStorage.setItem('user-userID', "");// check here
    this.stepper.selectedIndex = index;
    this.firstFormGroup.reset();
    this.InValidUsernput = false;
    this.secondFormGroup.reset();
    this.thirdFormGroup.reset();
  }

  roleChange(selectedRole: any) {
    console.log(selectedRole);
    if (selectedRole == "3") {
      console.log(selectedRole);
      this.displayGroups = false;
      this.displayGroupAdminGroups = false;
      this.displayActions = false;
    } else if (selectedRole == "2") {
      console.log(selectedRole);
      this.displayGroups = true;
      this.displayGroupAdminGroups = true;
      this.displayActions = true;
    } else {
      console.log(selectedRole);
      this.displayGroups = true;
      this.displayGroupAdminGroups = false;
      this.displayActions = false;
    }

    this.formSelectedRoleErr = false;
    console.log('displayGroupAdminGroups:', this.displayGroupAdminGroups);
  }

  // Validate UserId input field
  onKey(event: any) {
    console.log(event.target.value);
    if (event.target.value) {
      this.initializedPmanUser.racfId = this.firstFormGroup.value.racfIdFormControl;
      this.InValidUsernput = false;
    } else {
      this.InValidUsernput = true;
    }
  }

  validateUserInput() {
    this.InValidUsernput = false;
    this.formUserNameErr = false;
    this.formSelectedRoleErr = false;
    this.formUserGroupsErr = false;
    this.formUserAdminGroupsErr = false;
    this.formUserActionsErr = false;
  }

  closeModal() {
    this.activeModal.dismiss();
  }

}
