import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Output, ViewChild } from '@angular/core';
import { MatSidenavModule } from '@angular/material/sidenav';
import { Router } from '@angular/router';
import { NavItem } from './models/NavItem';
import { User } from './models/user';
import { UserService } from './services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularProject13';
  @Output() sidenavClose = new EventEmitter();

  @ViewChild('sidenav') sidenav!: MatSidenavModule;
  isExpanded = true;
  showSubmenu: boolean = true;
  isShowing = true;
  showSubSubMenu: boolean = true;
  showSubSubMenuToolGroup: boolean = true;
  public loading = false;
  isNavNotAllowed = true;
  public user!: User;


  menu: NavItem[] = [
    {
      displayName: 'Dashboard',
      iconName: 'dvr',
      route: '/dashboard',
      iconColor: 'mauve-icon'
    },
    {
      displayName: 'Groups',
      iconName: 'supervisor_account',
      route: '/tool-groups',
      iconColor: 'orange-icon'
    },
    {
      displayName: 'Users',
      iconName: 'perm_identity',
      route: '/pman-user',
      iconColor: 'twiterBlue-icon'
    },
  ];

  menuGroupAdmin: NavItem[] = [
    {
      displayName: 'Dashboard',
      iconName: 'dvr',
      route: '/dashboard',
      iconColor: 'mauve-icon'
    },
    {
      displayName: 'Users',
      iconName: 'perm_identity',
      route: '/pman-user',
      iconColor: 'twiterBlue-icon'
    },
  ];

  constructor(private userService: UserService, private router: Router, private datepipe: DatePipe) { }

  ngOnInit() {
    this.userService.onLoginStateChanged().subscribe((user: User) => {
      this.user = user;
      if (this.user && this.user.updateUserAllowed) {
        this.isNavNotAllowed = false;
        this.menu = this.user.role !== 'ADMIN' ? this.menuGroupAdmin : this.menu;
      } else {
        this.isNavNotAllowed = true;
      }
    });

    const date1 = this.datepipe.transform(new Date(), '_dd.MMM.yy_HH.mm.ss a');
    console.log('date1:', date1);

    if (!this.user) {
      const date2 = this.datepipe.transform(new Date(), '_dd.MMM.yy_HH.mm.ss a');
      console.log('date2:', date2);
      this.router.navigate(['/login']);
    }
  }

  ngAfterViewChecked() {
    const user = JSON.parse(sessionStorage.getItem('currentUser') || "{}");// check here
    if (user && user.updateUserAllowed) {
      this.isNavNotAllowed = false;
      this.menu = user.role !== 'ADMIN' ? this.menuGroupAdmin : this.menu;
    } else {
      this.isNavNotAllowed = true;
    }
  }

  public onSidenavClose = () => {
    this.sidenavClose.emit();
  }

  mouseenter() {
    if (!this.isExpanded) {
      this.isShowing = true;
    }
  }

  mouseleave() {
    if (!this.isExpanded) {
      this.isShowing = false;
    }
  }
  ut_toggleSidebar(sidenav: any) {
    sidenav.toggle();// check here from html
  }
}
