import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { AddQueryComponent } from '../add-query/add-query.component';
import { ConfirmationDialogService } from '../common-components/confirmation-dialog/confirmation-dialog.service';
import { PmanUser } from '../models/PmanUser';
import { QueryList, QueryParameters } from '../models/QueryList';
import { QueryParamInputComponent } from '../query-param-input/query-param-input.component';
import { QueryResultComponent } from '../query-result/query-result.component';
import { QueryService } from '../services/query.service';

@Component({
  selector: 'app-query',
  templateUrl: './query.component.html',
  styleUrls: ['./query.component.css']
})
export class QueryComponent implements OnInit {
  displayedColumns: string[] = ['id', 'name', 'description', 'associatedGroup', 'Action'];
  queryList: QueryList[] = [];

  pmanuser!: PmanUser;
  dataSource: any;
  public isLoading = true;
  value: string = '';
  public queryResultDialogRef!: MatDialogRef<QueryResultComponent>;
  public queryInputDialogRef!: MatDialogRef<QueryParamInputComponent>;
  private config = new MatSnackBarConfig();

  private dialogConfig = new MatDialogConfig();
  private modalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
  };

  public addQueryDialogRef!: MatDialogRef<AddQueryComponent>;

  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild(MatPaginator, { static: false }) paginator!: MatPaginator;

  // MatPaginator Inputs
  length = 100;
  pageSize = 10;
  pageSizeOptions: number[] = [25, 50, 75, 100];

  // MatPaginator Output
  pageEvent!: PageEvent;

  isExecuteQueryAllowed!: boolean;
  isUpdateQueryAllowed!: boolean;
  isDeleteQueryAllowed!: boolean;
  isAddQueryAllowed: boolean = true;

  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(str => +str);
    }
  }

  constructor(
    private modalService: NgbModal,
    private queryService: QueryService,
    private confirmationDialogService: ConfirmationDialogService,
    private snackBar: MatSnackBar,
    private changeDetectorRefs: ChangeDetectorRef,
    private dialog: MatDialog,
  ) { this.initializeDataTable(false); }


  ngOnInit(): void {
    const user = JSON.parse(sessionStorage.getItem('currentUser') || "{}");

    this.isExecuteQueryAllowed = user.executeQuery;
    this.isUpdateQueryAllowed = user.updateQuery;
    this.isDeleteQueryAllowed = user.deleteQuery;
    this.isAddQueryAllowed = user.addQueryAllowed;

    console.log('this.isExecuteQueryAllowed', this.isExecuteQueryAllowed);
    console.log('this.isUpdateQueryAllowed', this.isUpdateQueryAllowed);
    console.log('this.isDeleteQueryAllowed', this.isDeleteQueryAllowed);

    this.config.duration = 4000;
    this.config.panelClass = ['red-snackbar']
    this.config.horizontalPosition = 'end',
      this.config.verticalPosition = 'top'

    this.dialogConfig.hasBackdrop = true;
    this.dialogConfig.autoFocus = true;
    this.dialogConfig.maxWidth = '1000px';
    this.dialogConfig.disableClose = false;
  }

  ngAfterViewInit() {
    //this.dataSource.paginator = this.paginator;
    // this.dataSource.sort = this.sort;
  }

  initializeDataTable(reload: boolean) {

    const user = JSON.parse(sessionStorage.getItem('currentUser') || "{}");

    this.pmanuser = { id: "", userId: user.userName, racfId: user.userName, groupsAssignedTo: "" };// check here
    const sortState: Sort = { active: 'name', direction: 'asc' };

    this.queryService.getAllQueries(this.pmanuser, reload).then(response => {
      this.queryList = response;
      this.dataSource = new MatTableDataSource(response);

      // Default sort the table data by Name
      this.dataSource.sort = this.sort;
      this.sort.active = sortState.active;
      this.sort.direction = sortState.direction;
      this.sort.sortChange.emit(sortState);
      this.dataSource.paginator = this.paginator;

      this.isLoading = false;
      this.isExecuteQueryAllowed = user.executeQuery;
      this.isUpdateQueryAllowed = user.updateQuery;
      this.isDeleteQueryAllowed = user.deleteQuery;
    });
  }

  applyFilter() {
    const filterValue = this.value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  removeFilter() {
    this.value = '';
    const filterValue = this.value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  deleteQuery(id: string) {
    console.log('id:' + id)
    this.confirmationDialogService.confirm('Delete Query', 'Do you really want to delete this Query?')
      .then((confirmed) => {
        if (confirmed) {
          this.queryService.deleteQuery(id);
          this.config.panelClass = ['green-snackbar']
          this.snackBar.open('Query ' + id + ' Delete Successfully', '', this.config);
          this.dataSource.data.splice(this.dataSource.data.indexOf(id), 1);
          this.refresh();
          this.initializeDataTable(true);
        } else {
          console.log('User cancelled the operation');
        }
      })
      .catch(() => console.log('User dismissed the dialog (e.g., by using ESC, clicking the cross icon, or clicking outside the dialog)'));
  }

  refresh() {
    this.changeDetectorRefs.detectChanges();
  }

  executeQuery(queryId: string) {

    const result:any = this.queryList.find(({ id }) => id === queryId);
    const queryParameters: QueryParameters[] = result.parameters;
    const arr:any[] = [];

    queryParameters.forEach((myObj, index) => { arr.push(myObj); })

    const queryInputDialogRef = this.modalService.open(QueryParamInputComponent, this.modalOptions);
    queryInputDialogRef.componentInstance.queryParams = queryParameters;
    queryInputDialogRef.componentInstance.comments = result.executionComments;
    queryInputDialogRef.componentInstance.queryList = result;

    queryInputDialogRef.result.then((modal_result) => {
      console.log('Parameterized Query arr/modal_result-->' + arr.values() + 'modal_result: ' + modal_result.value);
      result.parameters = modal_result.parameters;
      result.executionComments = modal_result.executionComments;
      this.queryService.setQueryInputParams(result);

      if (result.ddlDml !== 'sel') {
        this.confirmationDialogService.confirm('This Query contain a '
          + result.ddlDml + ' statement ', 'Do you really want to proceed with your ' + result.ddlDml + '  Query?')
          .then((confirmed) => {
            if (confirmed) {
              this.dialog.open(QueryResultComponent, this.dialogConfig);
            }
          })
      } else if (result.ddlDml === 'sel') {
        this.dialog.open(QueryResultComponent, this.dialogConfig);
      }
    }).catch((modal_result) => { console.log('User dismissed or cancelled the dialog' + modal_result); });
  }

  addModifyQuery(queryID?: string) {
    if (queryID === undefined || queryID === null) { queryID = 'NewRecordRequest'; }
    window.sessionStorage.setItem('query-queryID', queryID);
    const modalRefrence = this.modalService.open(AddQueryComponent, this.modalOptions);

    modalRefrence.result.then((result) => {
      if (result === 'success') { this.initializeDataTable(true); }
    }, (exit) => { });
  }
}