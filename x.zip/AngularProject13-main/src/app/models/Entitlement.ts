export interface Entitlement {
    id: string;
    factory: string;
    adGroup: string;
    readAccess: boolean;
    writeAccess: boolean;
    control: boolean;
    engage: boolean;
}
