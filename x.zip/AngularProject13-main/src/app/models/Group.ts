export interface Group {
  name: string;
  status: string;
  factoryOwnerEmail: string;
  writeAccess?: boolean;
}
