export interface ToolGroups{
    id: string,
    name: string,
    description: string,
    checked? : boolean;
}