export interface User {
    userName: string;
    password: string;
    email: string;
    displayName: string;
    token: string;
    errorMsg : string;
    role: string;
    deleteQuery: boolean,
    executeQuery: boolean,
    updateQuery: boolean,
    deleteGroup: boolean,
    deleteUserAllowed: boolean,
    updateUserAllowed: boolean,
    updateGroupAllowed: boolean,
    exportAllowed: boolean,
    addQueryAllowed: boolean,
    adminUserCreationAllowed: boolean
   }
