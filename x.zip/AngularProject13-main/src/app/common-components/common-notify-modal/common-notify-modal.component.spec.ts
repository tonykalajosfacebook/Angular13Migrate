import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonNotifyModalComponent } from './common-notify-modal.component';

describe('CommonNotifyModalComponent', () => {
  let component: CommonNotifyModalComponent;
  let fixture: ComponentFixture<CommonNotifyModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommonNotifyModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonNotifyModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
