import { TestBed } from '@angular/core/testing';

import { CommonNotifyModalService } from './common-notify-modal.service';

describe('CommonNotifyModalService', () => {
  let service: CommonNotifyModalService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CommonNotifyModalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
