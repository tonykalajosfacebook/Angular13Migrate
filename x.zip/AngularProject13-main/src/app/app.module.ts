import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddQueryComponent } from './add-query/add-query.component';
import { CommonNotifyModalComponent } from './common-components/common-notify-modal/common-notify-modal.component';
import { FooterComponent } from './common-components/footer/footer.component';
import { ConfirmationDialogComponent } from './common-components/confirmation-dialog/confirmation-dialog.component';

import { MatStepperModule } from '@angular/material/stepper';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatRadioModule } from '@angular/material/radio';
import { MatChipsModule } from '@angular/material/chips';

import { ToastModule } from 'primeng/toast';
import { DropdownModule } from 'primeng/dropdown';


import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { MessageService } from 'primeng/api';
import { SignUpComponent } from './login/components/sign-up/sign-up.component';
import { GetEnvironmentPipe } from './login/components/sign-up/pipes/get-environment.pipe';
import { GetPermissionPipe } from './login/components/sign-up/pipes/get-permission.pipe';
import { PmanUserComponent } from './pman-user/pman-user.component';
import { PmanUserAddModifyComponent } from './pman-user-add-modify/pman-user-add-modify.component';
import { QueryComponent } from './query/query.component';
import { QueryParamInputComponent } from './query-param-input/query-param-input.component';
import { QueryResultComponent } from './query-result/query-result.component';
import { ToolGroupsComponent } from './tool-groups/tool-groups.component';
import { ToolGroupsAddModifyComponent } from './tool-groups-add-modify/tool-groups-add-modify.component';
import { NgxLoadingModule } from 'ngx-loading';

@NgModule({
  declarations: [
    AppComponent,
    AddQueryComponent,
    CommonNotifyModalComponent,
    FooterComponent,
    ConfirmationDialogComponent,
    HeaderComponent,
    LoginComponent,
    SignUpComponent,
    GetEnvironmentPipe,
    GetPermissionPipe,
    PmanUserComponent,
    PmanUserAddModifyComponent,
    QueryComponent,
    QueryParamInputComponent,
    QueryResultComponent,
    ToolGroupsComponent,
    ToolGroupsAddModifyComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,

    MatStepperModule,
    MatCardModule,
    MatIconModule,
    MatFormFieldModule,
    MatSelectModule,
    MatMenuModule,
    MatIconModule,
    MatTooltipModule,
    MatPaginatorModule,
    MatSortModule,
    MatTableModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatChipsModule,

    ToastModule,
    DropdownModule,

    NgxLoadingModule,

    NgbModule
  ],
  providers: [
    MessageService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
