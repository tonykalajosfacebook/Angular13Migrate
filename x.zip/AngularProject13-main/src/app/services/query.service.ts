import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { PmanUser } from '../models/PmanUser';
import { Parameter, Query } from '../models/Query';
import { QueryList } from '../models/QueryList';
import { QueryResult } from '../models/QueryResult';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class QueryService {

  inputParams: Parameter[] = [];
  queryList!: QueryList;// check here
  public allQueries: QueryList[] = [];

  constructor(private http: HttpClient) { }

  public addQuery(query: Query): Observable<Query> {
    return this.http.post<Query>('addQuery/', query, httpOptions);
  }

  response: QueryList[] = [];

  public getQuery<QueryList>(pmanuser: PmanUser) {
    return this.http.post
      (`getAllQueries/`, pmanuser, httpOptions).subscribe(
        (data: any) => {
          console.log(JSON.stringify(data));
          let str = JSON.stringify(data);
          this.response = JSON.parse(str);
          console.log("log:" + this.response);
          let str1 = JSON.stringify(this.response);
          console.log("log1:" + str1);

          for (let res in this.response) {
            console.log("vals:" + JSON.stringify(this.response[res].sql));
          }
        });
  }

  public async getAllQueries(pmanuser: PmanUser, reload: boolean): Promise<QueryList[]> {
    if (this.allQueries && !reload) {
      console.log('Service Call Not required. Data already present.');
      return this.allQueries;

    } else {
      console.log('Backend Service Call required.');
      this.allQueries = await this.http.post<QueryList[]>('getAllQueries/', pmanuser, httpOptions).toPromise() || []; // check here
      console.log("this.allQueries", this.allQueries);
      return this.allQueries;
    }
  }

  public deleteQuery(queryId: string): any {
    console.log(queryId);
    return this.http.get<any>('deleteQuery?queryId=' + queryId, httpOptions).subscribe(
      (data: any) => {
        console.log(data);
      }
    );
  }

  public executeQueryById(queryId: string, racfId: String): Observable<QueryList> {
    return this.http.get<QueryList>('executeQueryById?queryId=' + queryId + '&racfId=' + racfId, httpOptions).pipe(catchError(this.errorHandler));
  }

  public executeQuery(query: QueryList, racfId: String): Observable<QueryResult> {
    return this.http.post<QueryResult>('executeQuery?racfId=' + racfId, query, httpOptions).pipe(catchError(this.errorHandler));
  }

  public getQueryById(queryId: string): Observable<QueryList> {
    console.log(queryId);
    return this.http.get<QueryList>('getQueryById?queryId=' + queryId, httpOptions).pipe(catchError(this.errorHandler));
  }

  public downloadData(query: QueryList, requestURI: string): Observable<Blob> {
    httpOptions.headers.append('responseType', 'blob' as 'json');
    httpOptions.headers.append('Accept', 'application/json');

    const headers1 = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'environment': sessionStorage.getItem('environment') ? (sessionStorage.getItem('environment') || "") : ''
    });
    return this.http.post<Blob>(requestURI, query, { headers: httpOptions.headers, responseType: 'blob' as 'json' }).pipe(catchError(this.errorHandler));
  }

  public setQueryInputParams(queryList: QueryList) {
    this.queryList = queryList;
  }

  public getQueryInputParams(): QueryList {
    return this.queryList;
  }

  public clearData() {
    this.allQueries = [];
  }
  public errorHandler(error: HttpErrorResponse) {
    // return Observable.throwError(error.message || 'Server Error');
    return throwError(() => error.message || 'Server Error'); // check here
  }
}