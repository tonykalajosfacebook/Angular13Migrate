import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { PmanUser } from '../models/PmanUser';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class PmanUserService {

  public allPmanUsers: PmanUser | any;// check here

  constructor(private http: HttpClient) { }

  public async getAllPmanUsers(racfId: string, reload: boolean): Promise<PmanUser[]> {
    if (this.allPmanUsers && !reload) {
      console.log('Service Call Not required. Data already present.');
      return this.allPmanUsers;
    } else {
      console.log('Backend Service Call required.');
      this.allPmanUsers = await this.http.get<PmanUser[]>('getAllUsers?racfId=' + racfId, httpOptions).toPromise();
      return this.allPmanUsers;
    }
  }

  public getUserGroupsForCreateUser(racfId: string): Observable<PmanUser> {
    return this.http.get<PmanUser>('getUserGroupsForCreateUser?racfId=' + racfId, httpOptions).pipe(catchError(this.errorHandler));
  }

  public getUserGroupsforUpdateUser(racfId: string, userId: string): Observable<PmanUser> {
    return this.http.get<PmanUser>('getUserGroupsForUpdateUser?racfIdLoggedInUser=' +
      racfId + '&userId=' + userId, httpOptions).pipe(catchError(this.errorHandler));
  }

  public createUser(pmanUser: PmanUser): Observable<PmanUser> {
    return this.http.post<PmanUser>('createUser', pmanUser, httpOptions).pipe(catchError(this.errorHandler));
  }

  public deleteUser(userName: string, racfIdLoggedInUser: string): Observable<PmanUser> {
    return this.http.get<any>('deleteUser?userName=' + userName + '&racfIdLoggedInUser=' + racfIdLoggedInUser, httpOptions).pipe(catchError(this.errorHandler));
  }

  public getDBEnvironments(): Observable<string[]> {
    return this.http.get<any>('getDBEnvironments', httpOptions);
  }

  public errorHandler(error: HttpErrorResponse) {
    // return Observable.throwError(error.message || 'Server Error');
    return throwError(() => error.message || 'Server Error'); // check here
  }
}

