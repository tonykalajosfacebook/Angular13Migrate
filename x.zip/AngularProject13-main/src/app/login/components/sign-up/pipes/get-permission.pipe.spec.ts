import { GetPermissionPipe } from './get-permission.pipe';

describe('GetPermissionPipe', () => {
  it('create an instance', () => {
    const pipe = new GetPermissionPipe();
    expect(pipe).toBeTruthy();
  });
});
