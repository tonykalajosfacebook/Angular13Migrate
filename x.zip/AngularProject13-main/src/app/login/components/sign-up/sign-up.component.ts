import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SelectItem } from 'primeng/api';
import { EntitlementsService } from 'src/app/services/entitlements.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  itemSize: number = 10;
  selectedFactory: any;
  groups: any = {};
  factories: SelectItem[] = [];
  entitlements: any = {};
  permission = '';
  environment = 'Dev/Test';
  isloaded = false;

  constructor(public activeModal: NgbActiveModal, private entitlementService: EntitlementsService) { }

  ngOnInit(): void {
  }

  loadFactories(value: any) {
    this.isloaded = true;

    this.entitlementService.findAllEntitlementByFactoryName(value)
      .subscribe((ent: any) => {
        this.entitlements = ent;
      });
  }

}
